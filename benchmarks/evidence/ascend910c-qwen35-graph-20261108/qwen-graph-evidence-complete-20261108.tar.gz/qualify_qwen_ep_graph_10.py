"""Recompute intrinsic communication stages from the exact Qwen runtime."""
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import statistics

root = Path('/home/wuliang/aisimulate-repair-20261108/qwen-graph-fp32-r1')
points, sources = [], []
for tokens in (1,):
    run = root/f'qwen-pair-m{tokens}-r4'
    record = json.loads((run/'results.json').read_text())
    assert record['status'] == 'completed' and record['capacity'] == 16
    assert record['tokens_per_rank'] == tokens
    case, = record['cases']
    assert case['depth'] == 60 and case['validation'] == 'passed'
    assert len(case['rank_results']) == 16 and all(row['checked_elements'] > 0 for row in case['rank_results'])
    ranks = {}
    files = list(run.glob('profile/*_ascend_pt/ASCEND_PROFILER_OUTPUT/kernel_details.csv'))
    assert len(files) == 16
    for path in files:
        rows = list(csv.DictReader(path.open()))
        rows.sort(key=lambda row:Decimal(row['Start Time(us)'].strip()))
        rank, = {int(row['Device_id']) for row in rows}
        assert len(rows) == 13*60*5, (tokens, rank, len(rows))
        pairs = []
        for offset in range(0, len(rows), 5):
            group = rows[offset:offset+5]
            assert [row['Name'] for row in group] == [
                'aclnnInplaceCopy_CastAiCore_Cast', 'aclnnInplaceCopy_CastAiCore_Cast',
                'MoeLowLatencyDispatchV2', 'aclnnInplaceCopy_CastAiCore_Cast', 'MoeLowLatencyCombineV2']
            start = Decimal(group[0]['Start Time(us)'].strip())
            middle = Decimal(group[2]['Start Time(us)'].strip())+Decimal(group[2]['Duration(us)'])
            end = Decimal(group[4]['Start Time(us)'].strip())+Decimal(group[4]['Duration(us)'])
            assert start < middle < end
            pairs.append((start, middle, end))
        stages = {'dispatch':[], 'combine':[]}
        for sample in range(3, 13):
            # Reuse the structural split established by the GLM experiment.
            # Retain the first pair in raw data. Use the other59 for steady cost.
            selected = pairs[sample*60+1:(sample+1)*60]
            stages['dispatch'].append(sum(float(mid-start) for start,mid,end in selected)/59/1000)
            stages['combine'].append(sum(float(end-mid) for start,mid,end in selected)/59/1000)
        ranks[rank] = stages
        sources.append(dict(tokens=tokens, rank=rank, path=str(path.relative_to(root)),
                            sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    for operation in ('dispatch', 'combine'):
        samples = [max(ranks[rank][operation][index] for rank in range(16)) for index in range(10)]
        cv = statistics.pstdev(samples)/statistics.mean(samples)
        points.append(dict(role='expert_'+operation,tp=16,phase='decode',tokens=tokens,history=0,
                           samples_ms=samples,latency_ms=statistics.median(samples),cv=cv,
                           sample_count=len(samples),numerical_checks=sum(row['checked_elements'] for row in case['rank_results']),
                           qualified=cv<=.1,source_file=str((run/'results.json').relative_to(root)),
                           source_sha256=hashlib.sha256((run/'results.json').read_bytes()).hexdigest()))
report = dict(status='qualified' if all(point['qualified'] for point in points) else 'partial',
              points=points,sources=sources,
              collector_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              scope='Balanced independent arrivals, real60-pair Graph, cap16. Warmup3Graph batches excluded. '
                    'Pairs2..60 stage intervals retain casts, exclude the first program-entry pair. '
                    'Model expert arrival waiting is outside this calibration.')
(root/'ep-graph-qualified-rows-10.json').write_text(json.dumps(report,indent=2))
print(json.dumps(dict(status=report['status'],points=[{k:v for k,v in point.items() if k!='samples_ms'} for point in points])))
