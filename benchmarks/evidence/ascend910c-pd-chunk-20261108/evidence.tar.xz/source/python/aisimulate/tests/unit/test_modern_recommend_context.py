# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

from types import SimpleNamespace

import pytest

from aisimulate.compiler import _worker_engine_args
from aisimulate.config.cli import CoreRecommendationConfig
from aisimulate.config.engine import EnginePredictionConfig
from aisimulate.recommend import recommendation_to_sweeper
from aisimulate.sweeper import model_hw
from aisimulate.sweeper.deploy import _engine_args_payload
from aisimulate.sweeper.parallel_enum import DisaggParallelConfig, ParallelShape, ReplicaParallelConfig
from aisimulate.sweeper.sample import unroll_sample
from aisimulate.sweeper.search_space import branch_knob_choices

pytestmark = pytest.mark.unit


def _recommendation_config():
    return CoreRecommendationConfig.model_validate(
        {
            "engine": {
                "model": "Qwen/Qwen3-32B",
                "hardware": "h200_sxm",
                "mode": "disaggregated",
                "context_length": 1_000_000,
                "workers": {
                    "prefill": {"context_length": 64_000},
                    "decode": {"context_length": 128_000},
                },
            },
            "optimization": {
                "target": "throughput_per_gpu",
                "constraints": {"max_candidate_gpus": 8},
            },
        }
    )


def test_recommendation_context_limits_reach_search_space():
    search = recommendation_to_sweeper(_recommendation_config())

    assert search.search_space.context_length == 1_000_000
    assert search.search_space.prefill_context_length == 64_000
    assert search.search_space.decode_context_length == 128_000


def test_aggregate_worker_context_limit_must_use_engine_field():
    config = _recommendation_config().model_dump(mode="python")
    config["engine"]["workers"]["aggregated"] = {"context_length": 64_000}

    with pytest.raises(ValueError, match="engine.context_length"):
        CoreRecommendationConfig.model_validate(config)


@pytest.mark.parametrize(
    ("role", "context_length", "minimum"),
    [("prefill", 1023, 1025), ("prefill", 1024, 1025), ("decode", 1151, 1152)],
)
def test_role_context_limits_cover_configured_workload(role, context_length, minimum):
    config = _recommendation_config().model_dump(mode="python")
    config["traffic"] = {
        "source": {"type": "synthetic", "input_tokens": 1024, "output_tokens": 128},
        "load": {"type": "concurrency", "concurrency": 1},
        "stop": {"requests": 1},
    }
    CoreRecommendationConfig.model_validate(config)
    config["engine"]["workers"][role]["context_length"] = context_length

    with pytest.raises(ValueError, match=f"{role}.*{minimum}"):
        CoreRecommendationConfig.model_validate(config)

    config["engine"]["workers"][role]["context_length"] = minimum
    CoreRecommendationConfig.model_validate(config)


def test_role_context_limits_cover_default_workload_without_traffic():
    config = _recommendation_config().model_dump(mode="python")
    config["engine"]["workers"]["prefill"]["context_length"] = 1024

    with pytest.raises(ValueError, match="prefill.*1025"):
        CoreRecommendationConfig.model_validate({**config, "traffic": None})


def test_worker_context_limit_overrides_engine_context_for_prediction():
    engine = EnginePredictionConfig(
        model="Qwen/Qwen3-32B",
        hardware="h200_sxm",
        backend="trtllm",
        context_length=1_000_000,
        workers={"aggregated": {}},
    )
    worker = engine.workers.aggregated
    assert worker is not None
    worker.context_length = 64_000

    payload = _worker_engine_args(engine, worker, "agg", transfer_bytes_per_token=None)

    assert payload["max_model_len"] == 64_000


def test_disagg_sample_preserves_role_context_limits():
    search = recommendation_to_sweeper(_recommendation_config()).search_space
    shape = ParallelShape(tp=1, pp=1, dp=1, moe_tp=1, moe_ep=1)
    parallel = DisaggParallelConfig(
        prefill=ReplicaParallelConfig(shape=shape, replicas=1),
        decode=ReplicaParallelConfig(shape=shape, replicas=1),
    )
    selection = {
        "deployment_mode": "disagg",
        "backend": "vllm",
        "prefill_max_num_batched_tokens": 8192,
        "prefill_max_num_seqs": 1,
        "decode_max_num_batched_tokens": 8192,
        "decode_max_num_seqs": 256,
    }

    sample = unroll_sample(search_space=search, selection=selection, parallel_config=parallel)

    assert sample["prefill_context_length"] == 64_000
    assert sample["decode_context_length"] == 128_000

    payload = _engine_args_payload(sample, "prefill", backend_version="0.24.0")
    assert payload["max_model_len"] == 64_000
    decode_payload = _engine_args_payload(sample, "decode", backend_version="0.24.0")
    assert decode_payload["max_model_len"] == 128_000

    for role in ("prefill", "decode"):
        sample[f"{role}_context_length"] = None
        assert _engine_args_payload(sample, role, backend_version="0.24.0")["max_model_len"] == 1_000_000
    sample["context_length"] = None
    for role in ("prefill", "decode"):
        assert "max_model_len" not in _engine_args_payload(sample, role, backend_version="0.24.0")


def test_role_context_limits_work_without_shared_model_context(monkeypatch):
    shape = ParallelShape(tp=1, pp=1, dp=1, moe_tp=1, moe_ep=1)
    parallel = DisaggParallelConfig(
        prefill=ReplicaParallelConfig(shape=shape, replicas=1),
        decode=ReplicaParallelConfig(shape=shape, replicas=1),
    )
    seen = {}

    monkeypatch.setattr(
        model_hw,
        "resolve_model_hardware",
        lambda *args, **kwargs: SimpleNamespace(
            max_context=None, is_moe=False, enable_wideep=False, parallel_shape_candidates=None
        ),
    )
    monkeypatch.setattr(model_hw, "enumerate_disagg_configs", lambda **kwargs: [parallel])

    def feasible(shapes, **kwargs):
        seen[kwargs["max_seq_len"]] = True
        return dict.fromkeys(shapes, 1)

    monkeypatch.setattr(model_hw, "feasible_shape_tokens", feasible)

    result = model_hw.parallel_configs_for(
        "example/model",
        "example-gpu",
        gpu_budget=2,
        deployment_mode="disagg",
        backend="vllm",
        role_max_seq_len={"prefill": 64_000, "decode": 128_000},
    )

    assert result == [parallel]
    assert seen == {64_000: True, 128_000: True}


@pytest.mark.parametrize("role", ["aggregated", "prefill", "decode"])
@pytest.mark.parametrize(
    "domain,expected,selected",
    [
        (None, None, None),
        (8192, 8192, 8192),
        ({"choices": [4096, 8192]}, [4096, 8192], 8192),
        ({"range": {"min": 4096, "max": 8192, "step": 4096}}, [4096, 8192], 8192),
        ({"range": {"min": 4096, "max": 16384, "scale": "log"}}, [4096], 8192),
    ],
)
def test_chunk_search_survives_schema_lowering_selection_and_runner_payload(role, domain, expected, selected):
    raw = _recommendation_config().model_dump(mode="json")
    raw["engine"]["backend"] = "sglang"
    mode = "agg" if role == "aggregated" else "disagg"
    if mode == "agg":
        raw["engine"]["mode"] = "aggregated"
        raw["engine"]["workers"] = {"aggregated": {}}
    raw["engine"]["workers"][role].setdefault("scheduler", {})["chunked_prefill_size"] = domain
    config = CoreRecommendationConfig.model_validate(raw)
    reloaded = CoreRecommendationConfig.model_validate(config.model_dump(mode="json"))
    search = recommendation_to_sweeper(reloaded).search_space
    legacy_role = "agg" if role == "aggregated" else role
    name = f"{legacy_role}_chunked_prefill_size"
    assert getattr(search, name) == expected
    choices = branch_knob_choices(search, mode)
    if isinstance(expected, list):
        assert choices[name] == expected
    else:
        assert name not in choices
    if isinstance(domain, dict) and domain.get("range", {}).get("scale") == "log":
        assert search.engine_integer_log_ranges[name] == [4096, 16384]
    shape = ParallelShape(tp=1, pp=1, dp=2, moe_tp=1, moe_ep=1)
    replica = ReplicaParallelConfig(shape=shape, replicas=1)
    parallel = replica if mode == "agg" else DisaggParallelConfig(prefill=replica, decode=replica)
    roles = ("agg",) if mode == "agg" else ("prefill", "decode")
    selection = {"deployment_mode": mode, "backend": "sglang"}
    for active_role in roles:
        selection[f"{active_role}_max_num_batched_tokens"] = 8192
        selection[f"{active_role}_max_num_seqs"] = 32
    if selected is not None:
        selection[name] = selected
    sample = unroll_sample(search_space=search, selection=selection, parallel_config=parallel)
    assert sample[name] == selected
    payload = _engine_args_payload(sample, legacy_role, backend_version="0.5.22")
    if selected is None:
        assert "chunked_prefill_size" not in payload.get("sglang", {})
    else:
        # Global chunk passes through intact. The native rank constructor owns
        # the single division by attention DP2.
        assert payload["sglang"]["chunked_prefill_size"] == selected


@pytest.mark.parametrize("backend", ["vllm", "trtllm"])
def test_chunk_search_requires_sglang(backend):
    raw = _recommendation_config().model_dump(mode="json")
    raw["engine"]["backend"] = backend
    raw["engine"]["workers"]["prefill"]["scheduler"] = {
        "chunked_prefill_size": {"choices": [4096, 8192]}
    }
    with pytest.raises(ValueError, match="chunked_prefill_size requires backend=sglang"):
        CoreRecommendationConfig.model_validate(raw)
