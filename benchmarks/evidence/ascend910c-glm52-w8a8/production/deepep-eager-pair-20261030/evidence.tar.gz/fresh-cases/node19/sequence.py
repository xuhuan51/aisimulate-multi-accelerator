import argparse
import json
import subprocess
import sys
import time
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--directory', type=Path, required=True)
    parser.add_argument('--node-rank', type=int, required=True)
    args = parser.parse_args()
    directory = args.directory.resolve()
    manifest = directory / 'sequence.json'
    if manifest.exists():
        raise ValueError('Keep prior results; use a fresh sequence directory')
    records = []
    for index in range(6):
        case_dir = directory / f'case-{index}'
        command = [sys.executable, str(case_dir / 'run.py'), '--directory', str(case_dir),
                   '--node-rank', str(args.node_rank), '--port', str(30134 + index),
                   '--case-index', str(index), '--container', f'aisim-deepep-fresh-{index}-20261030']
        entry = {'index': index, 'command': command, 'started_at': time.time()}
        records.append(entry)
        manifest.write_text(json.dumps(records, indent=2) + '\n')
        with (case_dir / 'runner.log').open('w') as output:
            result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
        entry.update(returncode=result.returncode, finished_at=time.time())
        manifest.write_text(json.dumps(records, indent=2) + '\n')
        if result.returncode:
            raise RuntimeError(f'Case {index} failed; recorded without automatic retry')


if __name__ == '__main__':
    main()
