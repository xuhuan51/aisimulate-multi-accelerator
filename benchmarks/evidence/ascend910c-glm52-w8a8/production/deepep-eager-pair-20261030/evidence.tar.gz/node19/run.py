import argparse
import hashlib
import json
import os
import re
import socket
import subprocess
import threading
import time
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--directory', type=Path, required=True)
    parser.add_argument('--node-rank', type=int, choices=(0, 1), required=True)
    parser.add_argument('--port', type=int, default=30131)
    args = parser.parse_args()
    directory = args.directory.resolve()
    expected = ('npu1-20', 'npu1-19')[args.node_rank]
    if socket.gethostname() != expected:
        raise ValueError('Unexpected node for this frozen campaign')
    image = 'quay.io/ascend/sglang@sha256:5f384cab0e16a4951ed0bdc54e1280f2108aeda6b8ede90ee527d8f4b5146443'
    container = 'aisim-deepep-eager-pair-20261030'
    manifest = directory / 'campaign.json'
    if manifest.exists():
        raise ValueError('Preserve previous campaign; use a fresh directory')
    before = subprocess.check_output(['npu-smi', 'info'], text=True)
    (directory / 'npu-before.log').write_text(before)
    if before.count('No running processes found in NPU') != 8:
        raise RuntimeError('NPU is occupied')
    for filename, command in {
        'driver-version.info': ['cat', '/usr/local/Ascend/driver/version.info'],
        'network.log': ['ip', '-details', 'address', 'show', 'bond4'],
        'network-bond.log': ['cat', '/proc/net/bonding/bond4'],
        'cpu.log': ['lscpu'],
        'image.json': ['docker', 'image', 'inspect', image],
    }.items():
        (directory / filename).write_text(subprocess.check_output(command, text=True))
    create = ['docker', 'run', '-d', '--name', container, '--hostname', expected,
              '--network', 'host', '--privileged', '--shm-size', '32g',
              '--memory', '96g', '--mount', f'type=bind,src={directory},dst=/campaign']
    for path in ('/usr/local/Ascend/driver', '/usr/local/Ascend/firmware',
                 '/usr/local/sbin', '/etc/ascend_install.info'):
        create.extend(('--mount', f'type=bind,src={path},dst={path},readonly'))
    create.extend(('--entrypoint', '/bin/sleep', image, 'infinity'))
    command = ['docker', 'exec', container, 'timeout', '1800', 'torchrun',
               '--nproc-per-node', '16', '--nnodes', '2', '--node-rank', str(args.node_rank),
               '--master-addr', '10.120.72.20', '--master-port', str(args.port),
               '/campaign/collector.py', '--plan', '/campaign/plan.json',
               '--setup', '/campaign/setup.json', '--model-metadata', '/campaign/model-metadata',
               '--output', '/campaign/observations.json']
    state = {'status': 'prepared', 'host': expected, 'node_rank': args.node_rank,
             'create_command': create, 'command': command, 'started_at': time.time(),
             'collector_source_sha256': hashlib.sha256((directory / 'collector.py').read_bytes()).hexdigest(),
             'contamination': []}
    done = threading.Event()

    def save():
        temporary = manifest.with_suffix('.tmp')
        temporary.write_text(json.dumps(state, indent=2) + '\n')
        temporary.replace(manifest)

    def monitor():
        while not done.wait(15):
            try:
                snapshot = subprocess.check_output(['npu-smi', 'info'], text=True)
                active = {int(value) for value in re.findall(r'\|\s+\d+\s+\d+\s+\|\s+(\d+)\s+\|', snapshot)}
                owned = subprocess.check_output(['docker', 'top', container, '-eo', 'pid'], text=True)
                own_pids = {int(value.strip()) for value in owned.splitlines()[1:]}
                if active - own_pids:
                    (directory / 'external-processes.log').write_text(snapshot)
                    raise RuntimeError(f'External NPU processes: {sorted(active - own_pids)}')
            except Exception as error:
                state['contamination'].append(str(error))
                subprocess.run(['docker', 'stop', '--time', '10', container], check=False)
                return

    save()
    subprocess.run(create, check=True, stdout=subprocess.DEVNULL)
    watcher = threading.Thread(target=monitor, daemon=True)
    watcher.start()
    try:
        state['status'] = 'running'
        save()
        with (directory / 'collector.log').open('w') as output:
            result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
        state['returncode'] = result.returncode
        state['status'] = 'completed' if result.returncode == 0 and not state['contamination'] else 'failed'
    finally:
        done.set()
        watcher.join(timeout=20)
        state['finished_at'] = time.time()
        save()
        subprocess.run(['docker', 'stop', '--time', '10', container], check=False, stdout=subprocess.DEVNULL)
        for path in (directory, *directory.rglob('*')):
            os.chown(path, 5034, 5034)
    if state['status'] != 'completed':
        raise RuntimeError('Campaign failed; inspect recorded observations, no automatic retry')


if __name__ == '__main__':
    main()
