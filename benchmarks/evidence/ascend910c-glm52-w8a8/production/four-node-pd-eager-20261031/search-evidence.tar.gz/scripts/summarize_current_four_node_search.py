import csv
import hashlib
import io
import json
import math
import os
from pathlib import Path
import subprocess
import tarfile

ROOT = Path.cwd()
BASE = ROOT / 'aisimulate-output/current-eager-four-node-20261030-r2c1503d4'
EVIDENCE = ROOT / 'benchmarks/evidence/ascend910c-glm52-w8a8/production/four-node-pd-eager-20261031'
FIELDS = ['prefill_tp','prefill_attention_dp','prefill_moe_tp','prefill_moe_ep','prefill_replicas','decode_tp','decode_attention_dp','decode_moe_tp','decode_moe_ep','decode_replicas','used_gpus','concurrency']
METRICS = ['num_requests','completed_requests','rejected_requests','failed_requests','canceled_requests','mean_ttft_ms','mean_tpot_ms','output_throughput_tok_s','duration_ms']


def write_new(path, text):
    text = text.replace('\r\n','\n')
    if path.exists():
        assert path.read_text() == text, path
        return
    patch = '*** Begin Patch\n*** Add File: '+str(path)+'\n'+''.join('+'+line+'\n' for line in text.splitlines())+'*** End Patch\n'
    subprocess.run(['apply_patch'],input=patch,text=True,check=True,stdout=subprocess.DEVNULL)
    os.chown(path,5034,5034)


def compact(candidate):
    config = {key:candidate['config'][key] for key in FIELDS}
    for role in ('prefill','decode'):
        config[role+'_nodes'] = config[role+'_tp']*config[role+'_attention_dp']*config[role+'_replicas']//16
    return {'candidate_id':candidate['candidate_id'],'config':config,'metrics':{key:candidate['metrics'][key] for key in METRICS}}


EVIDENCE.mkdir(parents=True,exist_ok=True)
os.chown(EVIDENCE,5034,5034)
records = json.loads((BASE/'execution-summary.json').read_text())
summary = {'reported_date':'2026-10-31','runtime_source':'2c1503d4eb4deff38584051743f1d9ddacefd9eb','runtime_image':'sha256:9adbc67a84f1d0472c87c6217a08d6c7ccd8f43b44e80a5500549c966517574b','scope':{'node_budget':4,'devices_per_node':16,'deployment':'PD only','target':'output throughput','decode_execution_mode':'eager','overlap_scheduler':False,'shared_expert_overlap':True,'prefix_caching':False,'ignore_eos':True,'request_counts':'8K:2C;32K:C','warmup':'not reproduced; cold finite-request replay','concurrency_8k':[4,8,16,32],'concurrency_32k':[1,2,4,8],'accuracy_accepted':False},'cases':[],'winners':{},'failures':[],'counts':{}}
archive_paths = []
csv_stream = io.StringIO()
writer = csv.DictWriter(csv_stream,fieldnames=['case','candidate_id','status','reason_category','reason',*FIELDS,*METRICS])
writer.writeheader()
for record in records:
    folder = BASE/record['name']
    report_path = folder/'result/recommendation.json'
    report = json.loads(report_path.read_text())
    assert record['returncode']==0
    assert 'finite search space exhausted' in (folder/'command.log').read_text(errors='replace')
    successful = [row for row in report['candidates'] if row['status']=='feasible']
    for row in successful:
        metrics = row['metrics']
        assert metrics['num_requests']==metrics['completed_requests']==record['requests']
        assert metrics['failed_requests']==metrics['rejected_requests']==metrics['canceled_requests']==0
        assert metrics['total_input_tokens']==record['input_tokens']*record['requests']
        assert metrics['total_output_tokens']==1024*record['requests']
    for row in report['candidates']:
        writer.writerow({'case':record['name'],'candidate_id':row['candidate_id'],'status':row['status'],'reason_category':row.get('reason_category'),'reason':row.get('reason'),**{key:row['config'].get(key) for key in FIELDS},**{key:row.get('metrics',{}).get(key) for key in METRICS}})
        if row['status']!='feasible':
            summary['failures'].append({'case':record['name'],'candidate_id':row['candidate_id'],'reason_category':row['reason_category'],'reason':row['reason'],'config':{key:row['config'].get(key) for key in FIELDS}})
    best = next(row for row in successful if row['candidate_id']==report['views']['top_n'][0])
    case = {key:record[key] for key in ['name','input_tokens','output_tokens','concurrency','requests','elapsed_seconds','counts']}
    case.update(finite_space_exhausted=True,created_at_utc=report['provenance']['created_at'],best=compact(best),all_feasible_request_counts_verified=True)
    summary['cases'].append(case)
    for key,value in record['counts'].items():
        summary['counts'][key]=summary['counts'].get(key,0)+value
    winner=summary['winners'].get(str(record['input_tokens']))
    if winner is None or best['metrics']['output_throughput_tok_s'] > winner['best']['metrics']['output_throughput_tok_s']:
        summary['winners'][str(record['input_tokens'])]=case
    for relative in ['search.yaml','command.log','result/recommendation.json','result/recommendations/0001.yaml']:
        archive_paths.append((folder/relative,record['name']+'/'+relative))
for length,case in summary['winners'].items():
    folder=BASE/case['name']
    replay=json.loads((folder/'saved-best-replay/prediction.json').read_text())
    differences={key:replay[key]-case['best']['metrics'][key] for key in METRICS}
    assert all(math.isclose(replay[key],case['best']['metrics'][key],rel_tol=1e-12,abs_tol=1e-9) for key in METRICS)
    requests=[json.loads(line) for line in (folder/'saved-best-replay/requests.jsonl').read_text().splitlines()]
    assert len(requests)==case['requests']
    assert all(row['terminal_status']=='completed' and row['input_length']==int(length) and row['output_length']==1024 for row in requests)
    case['saved_replay']={'metric_differences':differences,'request_details_verified':len(requests)}
    target=EVIDENCE/f'best-{length}-1024.yaml'
    write_new(target,(folder/'result/recommendations/0001.yaml').read_text())
    for relative in ['saved-best-replay/prediction.json','saved-best-replay/requests.jsonl','saved-best-replay/resource-runtime.json']:
        archive_paths.append((folder/relative,case['name']+'/'+relative))
write_new(EVIDENCE/'candidates.csv',csv_stream.getvalue())
archive=EVIDENCE/'search-evidence.tar.gz'
with tarfile.open(archive,'w:gz') as output:
    for path,relative in archive_paths:
        output.add(path,arcname=relative)
    for name in ['run_current_four_node_search.py','summarize_current_four_node_search.py']:
        output.add(ROOT/'build/scheduler-audit-20261030'/name,arcname='scripts/'+name)
summary['archive']={'path':str(archive.relative_to(ROOT)),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size}
write_new(EVIDENCE/'report.json',json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
os.chown(archive,5034,5034)
print(json.dumps({'counts':summary['counts'],'winners':{key:value['best'] for key,value in summary['winners'].items()},'archive':summary['archive']}))
