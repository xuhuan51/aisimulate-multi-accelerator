import concurrent.futures
import copy
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path.cwd()
BASE = ROOT / 'aisimulate-output/current-eager-four-node-20261030-r2c1503d4'
ENV = dict(os.environ, SUDO_UID='5034', SUDO_GID='5034', AISIMULATE_910C_CPUSET='280-295', AISIMULATE_910C_MODEL='/data_lib/data/models/glm-q')
TEMPLATE = json.loads(subprocess.check_output([
    'docker','exec','aisim-node20-validation-20261027-v2','python3','-c',
    'import json,yaml; print(json.dumps(yaml.safe_load(open("/workspace/examples/cli/ascend910c-glm52-pd-eager-search.yaml"))))',
],text=True))
CASES = [(8192,32,64),(32768,8,8),(8192,16,32),(32768,4,4),(8192,8,16),(32768,2,2),(8192,4,8),(32768,1,1)]


def execute(case):
    length, concurrency, requests = case
    name = f'isl{length}-osl1024-c{concurrency}-n{requests}'
    directory = BASE/name
    directory.mkdir(parents=True,exist_ok=False)
    config = copy.deepcopy(TEMPLATE)
    config['engine']['model'] = ENV['AISIMULATE_910C_MODEL']
    config['traffic']['source']['input_tokens'] = length
    config['traffic']['load']['concurrency'] = concurrency
    config['traffic']['stop']['requests'] = requests
    for role in ('prefill','decode'):
        config['engine']['workers'][role]['parallelism'] = {'preset':'default'}
    config['optimizer'].update(max_trials=2000,parallelism=1,candidate_timeout_seconds=120.0)
    config_path = directory/'search.yaml'
    text = json.dumps(config,indent=2)+'\n'
    patch = '*** Begin Patch\n*** Add File: '+str(config_path)+'\n'+''.join('+'+line+'\n' for line in text.splitlines())+'*** End Patch\n'
    subprocess.run(['apply_patch',patch],check=True,stdout=subprocess.DEVNULL)
    os.chown(directory,5034,5034)
    os.chown(config_path,5034,5034)
    output = directory/'result'
    command = ['bash','scripts/run-ascend910c.sh','recommend','--stack','engine','--config',str(config_path),'--output-dir',str(output)]
    started = time.time()
    with (directory/'command.log').open('w') as log:
        completed = subprocess.run(command,env=ENV,stdout=log,stderr=subprocess.STDOUT)
    record = {'name':name,'input_tokens':length,'output_tokens':1024,'concurrency':concurrency,'requests':requests,'command':command,'returncode':completed.returncode,'elapsed_seconds':time.time()-started,'result_directory':str(output)}
    if (output/'recommendation.json').exists():
        report = json.loads((output/'recommendation.json').read_text())
        record['counts'] = report['counts']
        record['views'] = report['views']
        record['scope'] = report.get('scope')
        record['top'] = []
        for identifier in report['views']['top_n']:
            row = next(item for item in report['candidates'] if item['candidate_id']==identifier)
            fields = ['prefill_tp','prefill_attention_dp','prefill_moe_tp','prefill_moe_ep','prefill_replicas','decode_tp','decode_attention_dp','decode_moe_tp','decode_moe_ep','decode_replicas','used_gpus','concurrency']
            metrics = ['completed_requests','num_requests','rejected_requests','failed_requests','canceled_requests','mean_ttft_ms','mean_tpot_ms','output_throughput_tok_s','duration_ms']
            record['top'].append({'candidate_id':identifier,'config':{key:row['config'][key] for key in fields},'metrics':{key:row['metrics'][key] for key in metrics}})
    (directory/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    return record


if __name__ == '__main__':
    BASE.mkdir(parents=True,exist_ok=False)
    os.chown(BASE,5034,5034)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(execute,case) for case in CASES]
        results = [future.result() for future in futures]
    (BASE/'execution-summary.json').write_text(json.dumps(results,indent=2)+'\n')
