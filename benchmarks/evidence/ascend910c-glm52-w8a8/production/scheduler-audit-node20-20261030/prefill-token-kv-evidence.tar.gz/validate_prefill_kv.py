import concurrent.futures
import json
import subprocess
from pathlib import Path

BASE = Path('build/scheduler-audit-20261030')
PREFIX = ['docker', 'exec', '-w', '/workspace', '-e', 'PYTHONPATH=/workspace/python/aisimulate/src', 'aisim-node20-validation-20261027-v2', 'python3']
METRICS = ['completed_requests', 'mean_ttft_ms', 'mean_tpot_ms', 'output_throughput_tok_s', 'duration_ms']


def run(command, name):
    path = Path('/tmp') / ('aisim-prefill-kv-' + name + '.log')
    with path.open('w') as output:
        result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f'{name}: exit {result.returncode}; see {path}')
    return {'command': command, 'log': str(path), 'returncode': result.returncode}


def metrics(data):
    return {key: data[key] for key in METRICS}


def index_candidates(report):
    return {(item['config']['prefill_replicas'], item['config']['decode_replicas']): metrics(item['metrics']) for item in report['candidates'] if item['status'] == 'feasible'}


def search(case):
    length = case['input_tokens']
    command = [value.replace('pd-chunks-pd-', 'prefill-kv-pd-') for value in case['command']]
    execution = run(command, f'pd-{length}')
    output = Path(f'aisimulate-output/prefill-kv-pd-{length}-20261030')
    report = json.loads((output / 'recommendation.json').read_text())
    previous = json.loads(Path(f'aisimulate-output/pd-chunks-pd-{length}-20261030/recommendation.json').read_text())
    candidates = index_candidates(report)
    before = index_candidates(previous)
    assert report['counts']['feasible'] == 2 and report['counts']['failed'] == 0
    assert candidates == before, (candidates, before)
    replay = run(PREFIX + ['-m', 'aisimulate', 'predict', '--stack', 'engine', '--config', '/workspace/' + str(output / 'recommendations/0001.yaml'), '--output-dir', '/workspace/' + str(output / 'saved-best-replay')], f'pd-{length}-saved')
    prediction = metrics(json.loads((output / 'saved-best-replay/prediction.json').read_text()))
    best = next(item for item in report['candidates'] if item['candidate_id'] == report['views']['top_n'][0])
    assert prediction == metrics(best['metrics']), (prediction, metrics(best['metrics']))
    return {'input_tokens': length, 'execution': execution, 'counts': report['counts'], 'metrics': prediction, 'best_parallelism': {key: best['config'][key] for key in ('prefill_replicas', 'decode_replicas', 'prefill_tp', 'decode_tp', 'prefill_attention_dp', 'decode_attention_dp', 'prefill_moe_ep', 'decode_moe_ep')}, 'saved_replay': replay, 'saved_replay_differences': {}, 'previous_candidate_differences': {}, 'candidates': [{'prefill_replicas': key[0], 'decode_replicas': key[1], 'metrics': value} for key, value in sorted(candidates.items())]}


def aggregate():
    output = 'aisimulate-output/prefill-kv-aggregate-8192-20261030'
    command = PREFIX + ['-m', 'aisimulate', 'predict', '--stack', 'engine', '--config', '/workspace/examples/cli/ascend910c-glm52-8k1k.yaml', '--set', 'engine.model=/workspace/benchmarks/evidence/ascend910c-glm52-w8a8/production/deepep-contract-node19-20261024/model-metadata', '--set', 'engine.estimator_config.op_level.ascend.decode_execution_mode=eager', '--set', 'engine.workers.aggregated.scheduler.ignore_eos=true', '--set', 'traffic.load.concurrency=8', '--set', 'traffic.stop.requests=8', '--output-dir', '/workspace/' + output]
    execution = run(command, 'aggregate')
    current = metrics(json.loads(Path(output, 'prediction.json').read_text()))
    previous = metrics(json.loads(Path('aisimulate-output/before-prefill-kv-aggregate-8192-20261030/prediction.json').read_text()))
    assert current['completed_requests'] == 8
    return {'execution': execution, 'metrics': current, 'before_metrics': previous, 'change_from_previous': {key: current[key] - previous[key] for key in METRICS}}


def public_api():
    return run(PREFIX + ['-m', 'pytest', '-q', '-c', 'pytest.ini', 'python/aisimulate/tests/unit/sdk/models/test_ascend_glm52.py', 'python/aisimulate/tests/cross_package/test_core_public_api.py', '-k', 'not test_stable_function_signatures'], 'public')


if __name__ == '__main__':
    cases = json.loads((BASE / 'pd-chunks-search-commands.json').read_text())
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        jobs = {str(case['input_tokens']): pool.submit(search, case) for case in cases}
        jobs['aggregate'] = pool.submit(aggregate)
        jobs['public_api'] = pool.submit(public_api)
        results = {name: future.result() for name, future in jobs.items()}
    (BASE / 'prefill-kv-search-validation.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps({name: result.get('metrics', {'returncode': result['returncode']}) if 'returncode' in result else result.get('metrics') for name, result in results.items()}))
