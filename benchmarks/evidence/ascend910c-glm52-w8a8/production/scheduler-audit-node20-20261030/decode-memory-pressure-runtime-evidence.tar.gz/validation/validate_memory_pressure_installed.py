import concurrent.futures
import json
import os
import subprocess
from pathlib import Path

BASE = Path('build/scheduler-audit-20261030')
ROOT = Path.cwd()
ENV = dict(os.environ, SUDO_UID='5034', SUDO_GID='5034', AISIMULATE_910C_CPUSET='280-295', AISIMULATE_910C_IMAGE='aisimulate-910c:memory-pressure-staging-20261030', AISIMULATE_910C_MODEL=str(ROOT / 'benchmarks/evidence/ascend910c-glm52-w8a8/production/deepep-contract-node19-20261024/model-metadata'))
METRICS = ['completed_requests', 'mean_ttft_ms', 'mean_tpot_ms', 'output_throughput_tok_s', 'duration_ms']


def metrics(data):
    return {key: data[key] for key in METRICS}


def execute(command, name):
    log = Path('/tmp') / f'aisim-installed-memory-pressure-{name}.log'
    with log.open('w') as output:
        result = subprocess.run(command, env=ENV, stdout=output, stderr=subprocess.STDOUT)
    assert result.returncode == 0, (result.returncode, str(log))
    return {'command': command, 'log': str(log), 'returncode': result.returncode}


def search(case):
    length = case['input_tokens']
    command = [argument.replace('installed-pd-chunks-pd-', 'installed-memory-pressure-pd-') for argument in case['command']]
    result = execute(command, f'pd-{length}')
    installed = json.loads(Path(f'aisimulate-output/installed-memory-pressure-pd-{length}-20261030/recommendation.json').read_text())
    source = json.loads(Path(f'aisimulate-output/memory-pressure-pd-{length}-20261030/recommendation.json').read_text())
    def candidates(report):
        return {(item['config']['prefill_replicas'], item['config']['decode_replicas']): metrics(item['metrics']) for item in report['candidates'] if item['status'] == 'feasible'}
    assert installed['counts'] == source['counts']
    assert candidates(installed) == candidates(source)
    return {'input_tokens': length, 'execution': result, 'counts': installed['counts'], 'source_vs_installed_metric_differences': {}}


def aggregate():
    source = json.loads((BASE / 'memory-pressure-search-validation.json').read_text())['aggregate']
    previous = source['execution']['command']
    offset = previous.index('predict')
    command = ['bash', 'scripts/run-ascend910c.sh'] + [argument.replace('/workspace/', str(ROOT) + '/').replace('aisimulate-output/memory-pressure-aggregate-', 'aisimulate-output/installed-memory-pressure-aggregate-') for argument in previous[offset:]]
    result = execute(command, 'aggregate')
    installed = json.loads(Path('aisimulate-output/installed-memory-pressure-aggregate-8192-20261030/prediction.json').read_text())
    assert metrics(installed) == source['metrics']
    return {'execution': result, 'metrics': metrics(installed), 'source_vs_installed_metric_differences': {}}


if __name__ == '__main__':
    cases = json.loads((BASE / 'pd-chunks-installed-search-validation.json').read_text())
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        jobs = {str(case['input_tokens']): pool.submit(search, case) for case in cases}
        jobs['aggregate'] = pool.submit(aggregate)
        results = {name: future.result() for name, future in jobs.items()}
    (BASE / 'memory-pressure-installed-search-validation.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps({name: result.get('counts', result.get('metrics')) for name, result in results.items()}))
