import hashlib
import json
from pathlib import Path

import aisimulate
import aisimulate._runtime as runtime
from aisimulate.runner import EngineReplayRunnerFactory
from aisimulate.sweeper.replay import BackendDeploymentSpec, ReplayOutputRequirements, ReplaySpec
from aisimulate.sweeper.score import request_failure_violations

identity = json.loads(Path('/opt/aisimulate/native/native-identity.json').read_text())
native_sha = hashlib.sha256(Path(runtime.__file__).read_bytes()).hexdigest()
assert native_sha == identity['sha256']
assert runtime.engine_spec_schema_version() == identity['engine_spec_schema'] == 31
tables = []
site = Path(aisimulate.__file__).parent.parent
for relative in identity['packaged_ascend_tables_checked']:
    tables.append({'path': relative, 'sha256': hashlib.sha256((site/relative).read_bytes()).hexdigest()})
cases = []
for details in (False, True):
    deployment = BackendDeploymentSpec(
        deployment_mode='agg', backend='sglang', backend_version='0.5.22', num_workers=1,
        agg_engine_args={'rank': {
            'backend':'sglang', 'block_size':4, 'num_gpu_blocks':2, 'enable_prefix_caching':False,
            'sglang':{'clip_max_new_tokens':1,'chunked_prefill_size':16},
            'timing_model':{'type':'fixed','prefill_ms':2.0,'decode_ms':1.0},
        }},
    )
    spec = ReplaySpec(backend_deployment=deployment, workload={'isl':3,'osl':12,'concurrency':1,'request_count':2},goal={'target':'throughput'})
    runner = EngineReplayRunnerFactory().create(0)
    try:
        report = runner.run(spec,output_requirements=ReplayOutputRequirements(capture_per_request=details))
    finally:
        runner.close()
    expected = {'num_requests':2, 'completed_requests':0, 'rejected_requests':2, 'failed_requests':0, 'canceled_requests':0, 'output_throughput_tok_s':0,'num_ttft_samples':0}
    assert {key:report.metrics[key] for key in expected} == expected
    assert request_failure_violations(report.metrics) == ('rejected_requests=2',)
    cases.append({'capture_per_request':details,'metrics':expected,'search_gate':'rejected_requests=2'})
print(json.dumps({'identity':identity,'native_sha256':native_sha,'schema':runtime.engine_spec_schema_version(),'tables':tables,'cpu_oom_cases':cases}))
