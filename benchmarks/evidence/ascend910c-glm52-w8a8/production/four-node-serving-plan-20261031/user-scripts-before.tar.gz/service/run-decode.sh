#!/usr/bin/env bash
# 用途：在 Decode 容器内设置 Ascend/SGLang 环境并启动 GLM-5.2 Decode 服务。

set -Eeuo pipefail

# shellcheck source=pd-config.sh
source "$(dirname "$0")/pd-config.sh"

unset https_proxy http_proxy HTTPS_PROXY HTTP_PROXY ASCEND_LAUNCH_BLOCKING
# Ascend 官方环境脚本会读取未定义变量，加载期间临时关闭 nounset。
set +u
source /usr/local/Ascend/ascend-toolkit/set_env.sh
source /usr/local/Ascend/nnal/atb/set_env.sh
set -u

export PYTORCH_NPU_ALLOC_CONF=expandable_segments:True
export SGLANG_SET_CPU_AFFINITY=1
export STREAMS_PER_DEVICE=32
export ASCEND_MF_STORE_URL="tcp://${STORE_IP}:${STORE_PORT}"
export SGLANG_DISAGGREGATION_BOOTSTRAP_TIMEOUT=600
export TRANSFORMERS_VERBOSITY=error
export SGLANG_ENABLE_OVERLAP_PLAN_STREAM=1
export HCCL_BUFFSIZE=650
export SGLANG_DEEPEP_NUM_MAX_DISPATCH_TOKENS_PER_RANK=32
export TASK_QUEUE_ENABLE=0
export HCCL_SOCKET_IFNAME=$COMM_IFNAME
export GLOO_SOCKET_IFNAME=$COMM_IFNAME
export HCCL_IF_BASE_PORT
export SGLANG_NPU_USE_MULTI_STREAM=1

read -r -a decode_graph_batches <<<"$DECODE_GRAPH_BATCHES"

command=(
  python3 -m sglang.launch_server
  --model-path /models/glm-q
  --disaggregation-mode decode
  --disaggregation-transfer-backend ascend
  --host "$WORKER_IP"
  --port "$WORKER_PORT"
  --nnodes 1
  --node-rank 0
  --tp-size "$TP_SIZE"
  --dp-size "$DP_SIZE"
  --ep-size "$EP_SIZE"
  --mem-fraction-static "$MEM_FRACTION_STATIC"
  --max-running-requests "$DECODE_MAX_RUNNING_REQUESTS"
  --attention-backend ascend
  --device npu
  --quantization modelslim
  --served-model-name "$SERVED_MODEL_NAME"
  --moe-a2a-backend deepep
  --enable-dp-attention
  --deepep-mode low_latency
  --cuda-graph-backend-decode full
  --cuda-graph-max-bs-decode "$DECODE_GRAPH_MAX_BS"
  --cuda-graph-bs-decode "${decode_graph_batches[@]}"
  --watchdog-timeout 9000
  --context-length "$CONTEXT_LENGTH"
  --tokenizer-worker-num 4
  --prefill-round-robin-balance
  --disable-shared-experts-fusion
  --dtype bfloat16
  --load-balance-method round_robin
  --enable-cache-report
  --enable-metrics
  --enable-metrics-for-all-schedulers
  --trust-remote-code
)

printf '执行 Decode 命令：'
printf '%q ' "${command[@]}"
printf '\n'
exec "${command[@]}"
