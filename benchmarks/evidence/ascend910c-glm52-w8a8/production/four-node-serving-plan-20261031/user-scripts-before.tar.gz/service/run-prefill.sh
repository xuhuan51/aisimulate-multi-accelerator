#!/usr/bin/env bash
# 用途：在 Prefill 容器内设置 Ascend/SGLang 环境并启动 GLM-5.2 Prefill 服务。

set -Eeuo pipefail

# shellcheck source=pd-config.sh
source "$(dirname "$0")/pd-config.sh"

# 避免宿主机代理影响节点间的 HCCL、Gloo 和 MemFabric 通信。
unset https_proxy http_proxy HTTPS_PROXY HTTP_PROXY ASCEND_LAUNCH_BLOCKING

# 镜像内必须包含 CANN Toolkit 与 ATB 环境脚本。
# Ascend 官方环境脚本会读取未定义变量，加载期间临时关闭 nounset。
set +u
source /usr/local/Ascend/ascend-toolkit/set_env.sh
source /usr/local/Ascend/nnal/atb/set_env.sh
set -u

export PYTORCH_NPU_ALLOC_CONF=expandable_segments:True
export SGLANG_SET_CPU_AFFINITY=1
export STREAMS_PER_DEVICE=32
export ASCEND_MF_STORE_URL="tcp://${STORE_IP}:${STORE_PORT}"
export SGLANG_DISAGGREGATION_BOOTSTRAP_TIMEOUT=600
export TRANSFORMERS_VERBOSITY=error
export HCCL_SOCKET_IFNAME=$COMM_IFNAME
export GLOO_SOCKET_IFNAME=$COMM_IFNAME
export HCCL_IF_BASE_PORT

command=(
  python3 -m sglang.launch_server
  --model-path /models/glm-q
  --disaggregation-mode prefill
  --disaggregation-transfer-backend ascend
  --disaggregation-bootstrap-port "$WORKER_BOOTSTRAP_PORT"
  --host "$WORKER_IP"
  --port "$WORKER_PORT"
  --context-length "$CONTEXT_LENGTH"
  --nnodes 1
  --node-rank 0
  --tp-size "$TP_SIZE"
  --dp-size "$DP_SIZE"
  --mem-fraction-static "$MEM_FRACTION_STATIC"
  --max-running-requests "$PREFILL_MAX_RUNNING_REQUESTS"
  --attention-backend ascend
  --device npu
  --quantization modelslim
  --served-model-name "$SERVED_MODEL_NAME"
  --chunked-prefill-size "$PREFILL_CHUNK_SIZE"
  --max-prefill-tokens "$PREFILL_MAX_TOKENS"
  --disable-shared-experts-fusion
  --disable-cuda-graph
  --dtype bfloat16
  --load-balance-method follow_bootstrap_room
  --enable-dp-attention
  --enable-dp-lm-head
  --enable-cache-report
  --enable-metrics
  --enable-metrics-for-all-schedulers
  --trust-remote-code
)

printf '执行 Prefill 命令：'
printf '%q ' "${command[@]}"
printf '\n'
exec "${command[@]}"
