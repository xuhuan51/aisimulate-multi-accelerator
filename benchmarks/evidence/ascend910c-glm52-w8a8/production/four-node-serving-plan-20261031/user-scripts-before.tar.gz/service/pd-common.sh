#!/usr/bin/env bash
# 用途：为多 P/多 D 管理脚本提供拓扑解析、SSH、节点执行和容器检查函数。

PD_SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
PD_ROOT_DIR=$(cd -- "$PD_SCRIPT_DIR/.." && pwd)
# shellcheck source=pd-config.sh
source "$PD_SCRIPT_DIR/pd-config.sh"

read -r -a PREFILL_NODE_LIST <<<"$PREFILL_NODES"
read -r -a DECODE_NODE_LIST <<<"$DECODE_NODES"

SSH_OPTIONS=(
  -o BatchMode=yes
  -o ConnectTimeout="$SSH_CONNECT_TIMEOUT"
  -o StrictHostKeyChecking=accept-new
)

die() {
  echo "错误：$*" >&2
  exit 1
}

require_command() {
  command -v "$1" >/dev/null 2>&1 || die "缺少命令：$1"
}

local_has_ip() {
  ip -o -4 addr show | awk '{print $4}' | cut -d/ -f1 | grep -Fxq "$1"
}

require_controller_node() {
  local_has_ip "$ROUTER_IP" || die "请在控制节点/Router 节点 $ROUTER_IP 上执行本脚本"
}

parse_prefill_node() {
  local spec=$1
  local extra=${spec#*:*:*}
  IFS=: read -r NODE_IP NODE_PORT NODE_BOOTSTRAP <<<"$spec"
  [[ $extra != *:* ]] || return 1
  [[ -n $NODE_IP && -n $NODE_PORT && -n $NODE_BOOTSTRAP ]]
}

parse_decode_node() {
  local spec=$1
  local extra
  IFS=: read -r NODE_IP NODE_PORT extra <<<"$spec"
  [[ -n $NODE_IP && -n $NODE_PORT && -z ${extra:-} ]]
}

prefill_container_name() {
  printf '%s-%s' "$PREFILL_CONTAINER_PREFIX" "$1"
}

decode_container_name() {
  printf '%s-%s' "$DECODE_CONTAINER_PREFIX" "$1"
}

node_target() {
  printf '%s@%s' "$SSH_USER" "$1"
}

node_exec() {
  local node_ip=$1
  local command_text=$2
  if local_has_ip "$node_ip"; then
    bash -c "$command_text"
  else
    ssh "${SSH_OPTIONS[@]}" "$(node_target "$node_ip")" "$command_text"
  fi
}

node_copy() {
  local source_path=$1
  local node_ip=$2
  local destination=$3
  local_has_ip "$node_ip" && return 0
  scp -q "${SSH_OPTIONS[@]}" "$source_path" "$(node_target "$node_ip"):$destination"
}

all_worker_ips() {
  local spec
  for spec in "${PREFILL_NODE_LIST[@]}"; do
    parse_prefill_node "$spec" || continue
    printf '%s\n' "$NODE_IP"
  done
  for spec in "${DECODE_NODE_LIST[@]}"; do
    parse_decode_node "$spec" || continue
    printf '%s\n' "$NODE_IP"
  done
}

container_is_running() {
  local node_ip=$1
  local container=$2
  local running
  running=$(node_exec "$node_ip" "docker inspect -f '{{.State.Running}}' '$container'" 2>/dev/null || true)
  [[ $running == true ]]
}

show_container_logs() {
  local node_ip=$1
  local container=$2
  node_exec "$node_ip" "docker logs --tail 80 '$container'" >&2 || true
}

require_running_container() {
  local node_ip=$1
  local container=$2
  if ! container_is_running "$node_ip" "$container"; then
    echo "节点 $node_ip 上的容器 $container 已退出或无法查询，最近日志如下：" >&2
    show_container_logs "$node_ip" "$container"
    return 1
  fi
}

shell_quote() {
  printf '%q' "$1"
}
