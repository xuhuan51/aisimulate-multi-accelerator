#!/usr/bin/env bash
# 用途：离线检查多 Prefill/多 Decode 拓扑格式、节点重复、端口冲突和并行参数。
#
# 本脚本不连接远端、不启动容器，修改 service/pd-config.sh 后应先执行它。

set -Eeuo pipefail

# shellcheck source=../service/pd-common.sh
source "$(dirname "$0")/../service/pd-common.sh"

errors=0
warnings=0
declare -A used_ips=()
declare -A used_endpoints=()
declare -A prefill_ips=()

error() {
  echo "错误：$*" >&2
  errors=$((errors + 1))
}

warn() {
  echo "警告：$*" >&2
  warnings=$((warnings + 1))
}

is_uint() {
  [[ $1 =~ ^[0-9]+$ ]]
}

valid_port() {
  is_uint "$1" && ((10#$1 >= 1 && 10#$1 <= 65535))
}

valid_ipv4() {
  local ip=$1
  local octet
  local -a parts
  IFS=. read -r -a parts <<<"$ip"
  ((${#parts[@]} == 4)) || return 1
  for octet in "${parts[@]}"; do
    is_uint "$octet" || return 1
    ((10#$octet >= 0 && 10#$octet <= 255)) || return 1
  done
}

register_ip() {
  local ip=$1
  local role=$2
  if [[ -n ${used_ips[$ip]:-} ]]; then
    error "节点 $ip 同时或重复配置为 ${used_ips[$ip]} 和 $role；当前脚本每个节点独占全部 NPU"
  else
    used_ips[$ip]=$role
  fi
}

register_endpoint() {
  local ip=$1
  local port=$2
  local purpose=$3
  local key="$ip:$port"
  if [[ -n ${used_endpoints[$key]:-} ]]; then
    error "端口冲突 $key：${used_endpoints[$key]} 与 $purpose"
  else
    used_endpoints[$key]=$purpose
  fi
}

((${#PREFILL_NODE_LIST[@]} > 0)) || error "PREFILL_NODES 不能为空"
((${#DECODE_NODE_LIST[@]} > 0)) || error "DECODE_NODES 不能为空"

for index in "${!PREFILL_NODE_LIST[@]}"; do
  spec=${PREFILL_NODE_LIST[$index]}
  if ! parse_prefill_node "$spec"; then
    error "Prefill[$index] 格式错误：$spec；应为 IP:HTTP端口:Bootstrap端口"
    continue
  fi
  valid_ipv4 "$NODE_IP" || error "Prefill[$index] IP 无效：$NODE_IP"
  valid_port "$NODE_PORT" || error "Prefill[$index] HTTP 端口无效：$NODE_PORT"
  valid_port "$NODE_BOOTSTRAP" || error "Prefill[$index] Bootstrap 端口无效：$NODE_BOOTSTRAP"
  register_ip "$NODE_IP" "Prefill[$index]"
  register_endpoint "$NODE_IP" "$NODE_PORT" "Prefill[$index] HTTP"
  register_endpoint "$NODE_IP" "$NODE_BOOTSTRAP" "Prefill[$index] Bootstrap"
  prefill_ips[$NODE_IP]=1
done

for index in "${!DECODE_NODE_LIST[@]}"; do
  spec=${DECODE_NODE_LIST[$index]}
  if ! parse_decode_node "$spec"; then
    error "Decode[$index] 格式错误：$spec；应为 IP:HTTP端口"
    continue
  fi
  valid_ipv4 "$NODE_IP" || error "Decode[$index] IP 无效：$NODE_IP"
  valid_port "$NODE_PORT" || error "Decode[$index] HTTP 端口无效：$NODE_PORT"
  register_ip "$NODE_IP" "Decode[$index]"
  register_endpoint "$NODE_IP" "$NODE_PORT" "Decode[$index] HTTP"
done

valid_ipv4 "$ROUTER_IP" || error "ROUTER_IP 无效：$ROUTER_IP"
valid_ipv4 "$STORE_IP" || error "STORE_IP 无效：$STORE_IP"
valid_port "$ROUTER_PORT" || error "ROUTER_PORT 无效：$ROUTER_PORT"
valid_port "$STORE_PORT" || error "STORE_PORT 无效：$STORE_PORT"

first_prefill=${PREFILL_NODE_LIST[0]:-}
if [[ -n $first_prefill ]] && parse_prefill_node "$first_prefill"; then
  [[ $ROUTER_IP == "$NODE_IP" ]] || error "ROUTER_IP 必须是第一台 Prefill：$NODE_IP"
  [[ $STORE_IP == "$NODE_IP" ]] || error "STORE_IP 必须是第一台 Prefill：$NODE_IP"
fi
register_endpoint "$ROUTER_IP" "$ROUTER_PORT" "Router"
register_endpoint "$STORE_IP" "$STORE_PORT" "MemFabric Store"

for value_name in TP_SIZE DP_SIZE EP_SIZE NPU_DEVICE_COUNT CONTEXT_LENGTH DECODE_GRAPH_MAX_BS PREFILL_MAX_RUNNING_REQUESTS DECODE_MAX_RUNNING_REQUESTS PREFILL_CHUNK_SIZE PREFILL_MAX_TOKENS; do
  value=${!value_name}
  is_uint "$value" && ((10#$value > 0)) || error "$value_name 必须是正整数：$value"
done

if is_uint "$TP_SIZE" && is_uint "$NPU_DEVICE_COUNT"; then
  ((TP_SIZE <= NPU_DEVICE_COUNT)) || error "TP_SIZE=$TP_SIZE 不能大于 NPU_DEVICE_COUNT=$NPU_DEVICE_COUNT"
fi
if is_uint "$DP_SIZE" && is_uint "$TP_SIZE"; then
  ((DP_SIZE <= TP_SIZE)) || error "DP_SIZE=$DP_SIZE 不能大于 TP_SIZE=$TP_SIZE"
fi
if is_uint "$EP_SIZE" && is_uint "$TP_SIZE"; then
  ((EP_SIZE <= TP_SIZE)) || error "EP_SIZE=$EP_SIZE 不能大于 TP_SIZE=$TP_SIZE"
fi
if is_uint "$PREFILL_CHUNK_SIZE" && is_uint "$PREFILL_MAX_TOKENS" && is_uint "$CONTEXT_LENGTH"; then
  ((PREFILL_CHUNK_SIZE <= PREFILL_MAX_TOKENS)) || error "PREFILL_CHUNK_SIZE 不能大于 PREFILL_MAX_TOKENS"
  ((PREFILL_MAX_TOKENS <= CONTEXT_LENGTH)) || error "PREFILL_MAX_TOKENS 不能大于 CONTEXT_LENGTH"
fi
[[ $MEM_FRACTION_STATIC =~ ^0.[0-9]+$ ]] || error "MEM_FRACTION_STATIC 应为 0 到 1 之间的小数：$MEM_FRACTION_STATIC"
[[ $SGLANG_NPU_PROFILING == 0 || $SGLANG_NPU_PROFILING == 1 ]] || error "SGLANG_NPU_PROFILING 必须是 0 或 1：$SGLANG_NPU_PROFILING"

if is_uint "$TP_SIZE" && is_uint "$DP_SIZE" && is_uint "$DECODE_GRAPH_MAX_BS" && ((DP_SIZE > 0)); then
  if ((TP_SIZE % DP_SIZE != 0)); then
    error "TP_SIZE=$TP_SIZE 必须能被 DP_SIZE=$DP_SIZE 整除"
  else
    attention_tp=$((TP_SIZE / DP_SIZE))
    for batch in $DECODE_GRAPH_BATCHES; do
      valid_port "$batch" || { error "无效 Decode Graph batch：$batch"; continue; }
      ((batch % attention_tp == 0)) || error "Decode Graph batch=$batch 必须是 attention TP=$attention_tp 的整数倍"
      ((batch <= DECODE_GRAPH_MAX_BS)) || error "Decode Graph batch=$batch 大于 DECODE_GRAPH_MAX_BS=$DECODE_GRAPH_MAX_BS"
    done
  fi
fi

[[ $REMOTE_DIR != *[[:space:]]* ]] || error "REMOTE_DIR 不能包含空白字符：$REMOTE_DIR"

if ((errors > 0)); then
  echo "配置检查失败：$errors 个错误，$warnings 个警告" >&2
  exit 1
fi

echo "拓扑明细："
for index in "${!PREFILL_NODE_LIST[@]}"; do
  parse_prefill_node "${PREFILL_NODE_LIST[$index]}"
  printf "  Prefill[%s] %s:%s bootstrap=%s container=%s\n" "$index" "$NODE_IP" "$NODE_PORT" "$NODE_BOOTSTRAP" "$(prefill_container_name "$index")"
done
for index in "${!DECODE_NODE_LIST[@]}"; do
  parse_decode_node "${DECODE_NODE_LIST[$index]}"
  printf "  Decode[%s]  %s:%s container=%s\n" "$index" "$NODE_IP" "$NODE_PORT" "$(decode_container_name "$index")"
done
printf "  Router/Store %s router=%s store=%s\n" "$ROUTER_IP" "$ROUTER_PORT" "$STORE_PORT"

printf '配置检查通过：%d Prefill + %d Decode，Router/Store=%s\n' \
  "${#PREFILL_NODE_LIST[@]}" "${#DECODE_NODE_LIST[@]}" "$ROUTER_IP"
((warnings == 0)) || echo "配置包含 $warnings 个警告"
