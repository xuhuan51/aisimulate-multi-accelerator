#!/usr/bin/env python3
# 用途：读取统一性能测试目录中的 JSONL 结果，生成便于对比的 TSV 和 Markdown 汇总表。

import csv
import json
import sys
from pathlib import Path


FIELDS = [
    ("case", "case"),
    ("name", "name"),
    ("dataset", "dataset_name"),
    ("input_len", "configured_input_len"),
    ("output_len", "configured_output_len"),
    ("completed", "completed"),
    ("duration_s", "duration"),
    ("request_per_s", "request_throughput"),
    ("input_tok_per_s", "input_throughput"),
    ("output_tok_per_s", "output_throughput"),
    ("mean_ttft_ms", "mean_ttft_ms"),
    ("p99_ttft_ms", "p99_ttft_ms"),
    ("mean_tpot_ms", "mean_tpot_ms"),
    ("p99_tpot_ms", "p99_tpot_ms"),
    ("mean_itl_ms", "mean_itl_ms"),
    ("p99_itl_ms", "p99_itl_ms"),
    ("actual_concurrency", "concurrency"),
    ("cached_tokens", "cached_tokens"),
    ("cache_hit_rate", "cache_hit_rate"),
]


def read_env(path):
    values = {}
    if not path.exists():
        return values
    for line in path.read_text(encoding="utf-8").splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            values[key] = value
    return values


def format_value(value):
    if value is None:
        return ""
    if isinstance(value, float):
        return f"{value:.3f}"
    return str(value)


def load_rows(run_dir):
    rows = []
    for case_dir in sorted(path for path in run_dir.iterdir() if path.is_dir()):
        result_files = sorted(case_dir.glob("*.jsonl"))
        if not result_files:
            continue
        config = read_env(case_dir / "config.env")
        records = [
            json.loads(line)
            for line in result_files[-1].read_text(encoding="utf-8").splitlines()
            if line.strip()
        ]
        if not records:
            continue
        result = records[-1]
        cached_tokens = result.get("cached_tokens", result.get("total_cached_tokens"))
        cache_hit_rate = result.get("cache_hit_rate")
        if cache_hit_rate is None and cached_tokens is not None:
            total_input = result.get("total_input_tokens")
            if total_input:
                cache_hit_rate = cached_tokens / total_input
        result["cached_tokens"] = cached_tokens
        result["cache_hit_rate"] = cache_hit_rate
        result["case"] = config.get("CASE_ID", case_dir.name.split("_", 1)[0])
        result["name"] = config.get("CASE_NAME", case_dir.name)
        result["configured_input_len"] = config.get("INPUT_LENGTH", result.get("random_input_len"))
        result["configured_output_len"] = config.get("OUTPUT_LENGTH", result.get("random_output_len"))
        rows.append(result)
    return rows


def write_tsv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as output:
        writer = csv.writer(output, delimiter="\t")
        writer.writerow([label for label, _ in FIELDS])
        for row in rows:
            writer.writerow([format_value(row.get(key)) for _, key in FIELDS])


def write_markdown(path, rows):
    headers = [label for label, _ in FIELDS]
    lines = [
        "# 性能测试汇总",
        "",
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join(["---"] * len(headers)) + " |",
    ]
    for row in rows:
        values = [format_value(row.get(key)).replace("|", "\\|") for _, key in FIELDS]
        lines.append("| " + " | ".join(values) + " |")
    lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


def main():
    if len(sys.argv) != 2:
        raise SystemExit(f"用法：{sys.argv[0]} <workload-suite-result-dir>")
    run_dir = Path(sys.argv[1]).resolve()
    if not run_dir.is_dir():
        raise SystemExit(f"结果目录不存在：{run_dir}")
    rows = load_rows(run_dir)
    write_tsv(run_dir / "summary.tsv", rows)
    write_markdown(run_dir / "summary.md", rows)
    print(f"已汇总 {len(rows)} 组结果：{run_dir / 'summary.tsv'}")


if __name__ == "__main__":
    main()
