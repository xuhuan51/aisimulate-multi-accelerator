#!/usr/bin/env bash
# 用途：对指定 Prefill 或 Decode Worker 开启一段时间的 SGLang/Ascend 性能采样，并收集结果到本机。
#
# 用法：./tools/performance/profile-worker.sh <prefill|decode> <索引> [采样名称]
# 采样期间默认只等待；可通过 LOAD_COMMAND 在同一时间运行请求负载。

set -Eeuo pipefail

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
# shellcheck source=pd-common.sh
source "$SCRIPT_DIR/../../service/pd-common.sh"

role=${1:-}
index=${2:-}
profile_name=${3:-manual}
[[ $role == prefill || $role == decode ]] || die "用法：$0 <prefill|decode> <索引> [采样名称]"
[[ $index =~ ^[0-9]+$ ]] || die "索引必须是非负整数"
[[ $profile_name =~ ^[A-Za-z0-9_.-]+$ ]] || die "采样名称只能包含字母、数字、点、下划线和短横线"

PROFILE_SECONDS=${PROFILE_SECONDS:-10}
LOAD_COMMAND=${LOAD_COMMAND:-}
RESULT_DIR=${RESULT_DIR:-$PD_ROOT_DIR/results/performance/profile}
[[ $PROFILE_SECONDS =~ ^[1-9][0-9]*$ ]] || die "PROFILE_SECONDS 必须是正整数"

if [[ $role == prefill ]]; then
  ((index < ${#PREFILL_NODE_LIST[@]})) || die "Prefill 索引越界：$index"
  parse_prefill_node "${PREFILL_NODE_LIST[$index]}" || die "无法解析 Prefill[$index]"
  container=$(prefill_container_name "$index")
else
  ((index < ${#DECODE_NODE_LIST[@]})) || die "Decode 索引越界：$index"
  parse_decode_node "${DECODE_NODE_LIST[$index]}" || die "无法解析 Decode[$index]"
  container=$(decode_container_name "$index")
fi

require_running_container "$NODE_IP" "$container" || exit 1
profiling_enabled=$(node_exec "$NODE_IP" "docker inspect -f '{{range .Config.Env}}{{println .}}{{end}}' $(shell_quote "$container") | grep -Fx 'SGLANG_NPU_PROFILING=1'" 2>/dev/null || true)
[[ $profiling_enabled == SGLANG_NPU_PROFILING=1 ]] || die "容器未启用 NPU profiling。请设置 service/pd-config.sh 中 SGLANG_NPU_PROFILING=1 后重启服务"

timestamp=$(date +%Y%m%d_%H%M%S)
container_output="/tmp/sglang-profile/${timestamp}_${profile_name}_${role}${index}"
node_temp="/tmp/$(basename "$container_output")"
host_output="$RESULT_DIR/$(basename "$container_output")"
payload=$(printf '{"output_dir":"%s","activities":["CPU","GPU"],"record_shapes":true}' "$container_output")
worker_url="http://$NODE_IP:$NODE_PORT"
profile_started=0

stop_profile() {
  if ((profile_started)); then
    node_exec "$NODE_IP" "curl -fsS -X POST $(shell_quote "$worker_url/stop_profile")" >/dev/null || true
    profile_started=0
  fi
}
trap stop_profile EXIT INT TERM

echo "启动采样：$role[$index] $worker_url，输出=$container_output"
node_exec "$NODE_IP" "curl -fsS -X POST -H 'Content-Type: application/json' -d $(shell_quote "$payload") $(shell_quote "$worker_url/start_profile")"
profile_started=1

load_status=0
if [[ -n $LOAD_COMMAND ]]; then
  echo "运行采样负载：$LOAD_COMMAND"
  set +e
  bash -c "$LOAD_COMMAND"
  load_status=$?
  set -e
else
  echo "采样 ${PROFILE_SECONDS} 秒；本脚本不发送推理请求"
  sleep "$PROFILE_SECONDS"
fi

stop_profile
mkdir -p "$RESULT_DIR"
node_exec "$NODE_IP" "rm -rf $(shell_quote "$node_temp") && docker cp $(shell_quote "$container:$container_output") $(shell_quote "$node_temp")"
if local_has_ip "$NODE_IP"; then
  mv "$node_temp" "$host_output"
else
  scp -qr "${SSH_OPTIONS[@]}" "$(node_target "$NODE_IP"):$node_temp" "$host_output"
  node_exec "$NODE_IP" "rm -rf $(shell_quote "$node_temp")"
fi

echo "采样结果：$host_output"
exit "$load_status"
