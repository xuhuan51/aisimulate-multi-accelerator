#!/usr/bin/env bash
# 用途：按顺序执行六组 PD serving 性能测试，将每组日志、JSONL 和汇总结果统一保存到 results 目录。

set -Eeuo pipefail

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
# shellcheck source=pd-common.sh
source "$SCRIPT_DIR/../../service/pd-common.sh"

BENCHMARK_SCRIPT="$SCRIPT_DIR/run-benchmark.sh"
SUMMARY_SCRIPT="$SCRIPT_DIR/summarize-workload-results.py"

# 默认执行全部用例。也可设置 CASES="1 3 6" 只运行指定组。
CASES=${CASES:-"1 2 3 4 5 6"}
NUM_PROMPTS=${NUM_PROMPTS:-80}
MAX_CONCURRENCY=${MAX_CONCURRENCY:-16}
WARMUP_REQUESTS=${WARMUP_REQUESTS:-10}
REQUEST_RATE=${REQUEST_RATE:-inf}
RANDOM_RANGE_RATIO=${RANDOM_RANGE_RATIO:-1}
# 4K/1K 固定用例使用中等并发，避免一次提交过多请求导致 PD 链路超时。
CASE2_NUM_PROMPTS=${CASE2_NUM_PROMPTS:-320}
CASE2_MAX_CONCURRENCY=${CASE2_MAX_CONCURRENCY:-32}
CASE2_WARMUP_REQUESTS=${CASE2_WARMUP_REQUESTS:-$WARMUP_REQUESTS}

# 32K 长输出开销很大，默认使用较小规模；设为 1 可使用上面的统一规模。
FULL_SCALE_LONG_OUTPUT=${FULL_SCALE_LONG_OUTPUT:-0}
LONG_OUTPUT_NUM_PROMPTS=${LONG_OUTPUT_NUM_PROMPTS:-16}
LONG_OUTPUT_MAX_CONCURRENCY=${LONG_OUTPUT_MAX_CONCURRENCY:-4}
LONG_OUTPUT_WARMUP_REQUESTS=${LONG_OUTPUT_WARMUP_REQUESTS:-4}

# prefix32k：共享前缀本身为 32K，占总输入约 60%。
# total32k：总输入为 32K，其中共享前缀约占 60%。
CACHE_CASE_MODE=${CACHE_CASE_MODE:-prefix32k}
CACHE_NUM_GROUPS=${CACHE_NUM_GROUPS:-8}
CACHE_PROMPTS_PER_GROUP=${CACHE_PROMPTS_PER_GROUP:-10}
CACHE_MAX_CONCURRENCY=${CACHE_MAX_CONCURRENCY:-$MAX_CONCURRENCY}
CACHE_WARMUP_REQUESTS=${CACHE_WARMUP_REQUESTS:-$WARMUP_REQUESTS}

FLUSH_CACHE_BEFORE_CASE=${FLUSH_CACHE_BEFORE_CASE:-1}
CONTINUE_ON_ERROR=${CONTINUE_ON_ERROR:-0}
RESUME=${RESUME:-1}
RESULT_ROOT=${RESULT_ROOT:-$PD_ROOT_DIR/results}
RUN_DIR=${RUN_DIR:-$RESULT_ROOT/workload-suite_$(date +%Y%m%d_%H%M%S)}

require_command python3
[[ -x $BENCHMARK_SCRIPT ]] || die "benchmark 脚本不存在或不可执行：$BENCHMARK_SCRIPT"
[[ -f $SUMMARY_SCRIPT ]] || die "汇总脚本不存在：$SUMMARY_SCRIPT"

is_positive_integer() {
  [[ $1 =~ ^[1-9][0-9]*$ ]]
}

for value_name in NUM_PROMPTS MAX_CONCURRENCY WARMUP_REQUESTS CASE2_NUM_PROMPTS CASE2_MAX_CONCURRENCY CASE2_WARMUP_REQUESTS LONG_OUTPUT_NUM_PROMPTS LONG_OUTPUT_MAX_CONCURRENCY LONG_OUTPUT_WARMUP_REQUESTS CACHE_NUM_GROUPS CACHE_PROMPTS_PER_GROUP CACHE_MAX_CONCURRENCY CACHE_WARMUP_REQUESTS; do
  value=${!value_name}
  if [[ $value_name == *WARMUP_REQUESTS ]]; then
    [[ $value =~ ^[0-9]+$ ]] || die "$value_name 必须是非负整数：$value"
  else
    is_positive_integer "$value" || die "$value_name 必须是正整数：$value"
  fi
done

((CASE2_NUM_PROMPTS >= CASE2_MAX_CONCURRENCY)) || die "CASE2_NUM_PROMPTS 不能小于 CASE2_MAX_CONCURRENCY"
[[ $FULL_SCALE_LONG_OUTPUT == 0 || $FULL_SCALE_LONG_OUTPUT == 1 ]] || die "FULL_SCALE_LONG_OUTPUT 必须是 0 或 1"
[[ $FLUSH_CACHE_BEFORE_CASE == 0 || $FLUSH_CACHE_BEFORE_CASE == 1 ]] || die "FLUSH_CACHE_BEFORE_CASE 必须是 0 或 1"
[[ $CONTINUE_ON_ERROR == 0 || $CONTINUE_ON_ERROR == 1 ]] || die "CONTINUE_ON_ERROR 必须是 0 或 1"
[[ $RESUME == 0 || $RESUME == 1 ]] || die "RESUME 必须是 0 或 1"
[[ $CACHE_CASE_MODE == prefix32k || $CACHE_CASE_MODE == total32k ]] || die "CACHE_CASE_MODE 只能是 prefix32k 或 total32k"

for case_id in $CASES; do
  [[ $case_id =~ ^[1-6]$ ]] || die "CASES 只能包含 1 到 6：$case_id"
done

case_selected() {
  local wanted=$1
  local item
  for item in $CASES; do
    [[ $item == "$wanted" ]] && return 0
  done
  return 1
}

mkdir -p "$RUN_DIR"
status_file="$RUN_DIR/status.tsv"
if [[ ! -f $status_file || $RESUME == 0 ]]; then
  printf 'case\tname\texit_status\telapsed_seconds\tresult_dir\n' >"$status_file"
fi

{
  echo "RUN_DIR=$RUN_DIR"
  echo "CASES=$CASES"
  echo "NUM_PROMPTS=$NUM_PROMPTS"
  echo "MAX_CONCURRENCY=$MAX_CONCURRENCY"
  echo "WARMUP_REQUESTS=$WARMUP_REQUESTS"
  echo "CASE2_NUM_PROMPTS=$CASE2_NUM_PROMPTS"
  echo "CASE2_MAX_CONCURRENCY=$CASE2_MAX_CONCURRENCY"
  echo "CASE2_WARMUP_REQUESTS=$CASE2_WARMUP_REQUESTS"
  echo "REQUEST_RATE=$REQUEST_RATE"
  echo "RANDOM_RANGE_RATIO=$RANDOM_RANGE_RATIO"
  echo "FULL_SCALE_LONG_OUTPUT=$FULL_SCALE_LONG_OUTPUT"
  echo "CACHE_CASE_MODE=$CACHE_CASE_MODE"
  echo "FLUSH_CACHE_BEFORE_CASE=$FLUSH_CACHE_BEFORE_CASE"
  echo "IMAGE=$IMAGE"
  echo "MODEL_DIR=$MODEL_DIR"
  echo "SERVED_MODEL_NAME=$SERVED_MODEL_NAME"
  echo "PREFILL_NODES=$PREFILL_NODES"
  echo "DECODE_NODES=$DECODE_NODES"
  echo "CONTEXT_LENGTH=$CONTEXT_LENGTH"
  echo "TP_SIZE=$TP_SIZE"
  echo "DP_SIZE=$DP_SIZE"
  echo "EP_SIZE=$EP_SIZE"
  echo "PREFILL_CHUNK_SIZE=$PREFILL_CHUNK_SIZE"
  echo "PREFILL_MAX_TOKENS=$PREFILL_MAX_TOKENS"
  echo "DECODE_GRAPH_BATCHES=$DECODE_GRAPH_BATCHES"
  echo "PREFILL_MAX_RUNNING_REQUESTS=$PREFILL_MAX_RUNNING_REQUESTS"
  echo "DECODE_MAX_RUNNING_REQUESTS=$DECODE_MAX_RUNNING_REQUESTS"
} >"$RUN_DIR/suite-config.env"

run_case() {
  local case_id=$1
  local case_name=$2
  local dataset_name=$3
  local input_len=$4
  local output_len=$5
  local num_prompts=$6
  local max_concurrency=$7
  local warmup_requests=$8
  shift 8
  local case_dir="$RUN_DIR/${case_id}_${case_name}"
  local start_time
  local elapsed
  local status
  local -a extra_args=("$@")

  if [[ $RESUME == 1 && -f $case_dir/.complete ]]; then
    echo "跳过已完成用例：$case_id $case_name"
    return 0
  fi

  mkdir -p "$case_dir"
  {
    echo "CASE_ID=$case_id"
    echo "CASE_NAME=$case_name"
    echo "DATASET_NAME=$dataset_name"
    echo "INPUT_LENGTH=$input_len"
    echo "OUTPUT_LENGTH=$output_len"
    echo "NUM_PROMPTS=$num_prompts"
    echo "MAX_CONCURRENCY=$max_concurrency"
    echo "WARMUP_REQUESTS=$warmup_requests"
    echo "REQUEST_RATE=$REQUEST_RATE"
    echo "RANDOM_RANGE_RATIO=$RANDOM_RANGE_RATIO"
  } >"$case_dir/config.env"

  if [[ $FLUSH_CACHE_BEFORE_CASE == 1 ]]; then
    extra_args+=(--flush-cache)
  fi

  echo
  echo "===== 用例 $case_id：$case_name ====="
  echo "结果目录：$case_dir"
  start_time=$(date +%s)

  set +e
  NUM_PROMPTS=$num_prompts \
    MAX_CONCURRENCY=$max_concurrency \
    RANDOM_INPUT_LEN=$input_len \
    RANDOM_OUTPUT_LEN=$output_len \
    RANDOM_RANGE_RATIO=$RANDOM_RANGE_RATIO \
    REQUEST_RATE=$REQUEST_RATE \
    WARMUP_REQUESTS=$warmup_requests \
    DATASET_NAME=$dataset_name \
    RESULT_DIR="$case_dir" \
    "$BENCHMARK_SCRIPT" "${extra_args[@]}" 2>&1 | tee "$case_dir/benchmark.log"
  status=${PIPESTATUS[0]}
  set -e

  elapsed=$(($(date +%s) - start_time))
  printf '%s\t%s\t%s\t%s\t%s\n' "$case_id" "$case_name" "$status" "$elapsed" "$case_dir" >>"$status_file"
  if ((status == 0)); then
    touch "$case_dir/.complete"
  else
    rm -f "$case_dir/.complete"
  fi
  return "$status"
}

suite_failed=0

execute_case() {
  local status
  if run_case "$@"; then
    return 0
  else
    status=$?
  fi

  suite_failed=1
  if [[ $CONTINUE_ON_ERROR != 1 ]]; then
    python3 "$SUMMARY_SCRIPT" "$RUN_DIR"
    echo "用例失败，停止后续测试。设置 CONTINUE_ON_ERROR=1 可继续。" >&2
    exit "$status"
  fi
}

case_selected 1 && execute_case 01 decode_3.5k_1.5k random-ids 3584 1536 "$NUM_PROMPTS" "$MAX_CONCURRENCY" "$WARMUP_REQUESTS"

if case_selected 2; then
  if ((CASE2_MAX_CONCURRENCY > PREFILL_MAX_RUNNING_REQUESTS || CASE2_MAX_CONCURRENCY > DECODE_MAX_RUNNING_REQUESTS)); then
    echo "警告：第 2 组客户端并发为 $CASE2_MAX_CONCURRENCY，但当前服务端限制为 Prefill=$PREFILL_MAX_RUNNING_REQUESTS、Decode=$DECODE_MAX_RUNNING_REQUESTS。"
    echo "      超出服务端限制的请求会排队；提高该值前应先修改服务配置并重启。"
  fi
  execute_case 02 fixed_4k_1k random-ids 4096 1024 \
    "$CASE2_NUM_PROMPTS" "$CASE2_MAX_CONCURRENCY" "$CASE2_WARMUP_REQUESTS"
fi

case_selected 3 && execute_case 03 long_context_8k_1k random-ids 8192 1024 "$NUM_PROMPTS" "$MAX_CONCURRENCY" "$WARMUP_REQUESTS"
case_selected 4 && execute_case 04 long_text_32k_1k random-ids 32768 1024 "$NUM_PROMPTS" "$MAX_CONCURRENCY" "$WARMUP_REQUESTS"

if case_selected 5; then
  if [[ $FULL_SCALE_LONG_OUTPUT == 1 ]]; then
    long_prompts=$NUM_PROMPTS
    long_concurrency=$MAX_CONCURRENCY
    long_warmup=$WARMUP_REQUESTS
  else
    long_prompts=$LONG_OUTPUT_NUM_PROMPTS
    long_concurrency=$LONG_OUTPUT_MAX_CONCURRENCY
    long_warmup=$LONG_OUTPUT_WARMUP_REQUESTS
  fi
  execute_case 05 long_output_1k_32k random-ids 1024 32768 "$long_prompts" "$long_concurrency" "$long_warmup"
fi

if case_selected 6; then
  if [[ $CACHE_CASE_MODE == prefix32k ]]; then
    cache_prefix_len=32768
    cache_question_len=21845
    cache_name=cache_prefix32k_output300_target60pct
  else
    cache_prefix_len=19661
    cache_question_len=13107
    cache_name=cache_total32k_output300_target60pct
  fi
  cache_prompts=$((CACHE_NUM_GROUPS * CACHE_PROMPTS_PER_GROUP))
  execute_case 06 "$cache_name" generated-shared-prefix \
    "$((cache_prefix_len + cache_question_len))" 300 \
    "$cache_prompts" "$CACHE_MAX_CONCURRENCY" "$CACHE_WARMUP_REQUESTS" \
    --gsp-num-groups "$CACHE_NUM_GROUPS" \
    --gsp-prompts-per-group "$CACHE_PROMPTS_PER_GROUP" \
    --gsp-system-prompt-len "$cache_prefix_len" \
    --gsp-question-len "$cache_question_len" \
    --gsp-output-len 300 \
    --gsp-range-ratio 1 \
    --cache-report
fi

python3 "$SUMMARY_SCRIPT" "$RUN_DIR"
echo
echo "全部用例执行结束：$RUN_DIR"
echo "状态汇总：$status_file"
echo "性能汇总：$RUN_DIR/summary.tsv"
exit "$suite_failed"
