#!/usr/bin/env bash
# 用途：逐级扫描客户端并发度，并为每个并发度保存独立的 SGLang serving 性能结果和日志。
#
# 本脚本不会自动修改服务端 MAX_RUNNING_REQUESTS。默认会检查扫描上限是否超过
# Prefill/Decode 中较小的限制，避免把服务端排队误判为并行能力不足。

set -Eeuo pipefail

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
# shellcheck source=pd-common.sh
source "$SCRIPT_DIR/../../service/pd-common.sh"

START_CONCURRENCY=${START_CONCURRENCY:-1}
END_CONCURRENCY=${END_CONCURRENCY:-32}
STEP=${STEP:-1}
NUM_PROMPTS_PER_CASE=${NUM_PROMPTS_PER_CASE:-}
RANDOM_INPUT_LEN=${RANDOM_INPUT_LEN:-32768}
RANDOM_OUTPUT_LEN=${RANDOM_OUTPUT_LEN:-500}
WARMUP_REQUESTS=${WARMUP_REQUESTS:-10}
CONTINUE_ON_ERROR=${CONTINUE_ON_ERROR:-0}
ALLOW_OVER_CAPACITY=${ALLOW_OVER_CAPACITY:-0}
RESTART_SERVICE_EACH_RUN=${RESTART_SERVICE_EACH_RUN:-0}
RESULT_ROOT=${RESULT_ROOT:-$PD_ROOT_DIR/results/performance/concurrency-sweep}

for value_name in START_CONCURRENCY END_CONCURRENCY STEP; do
  value=${!value_name}
  [[ $value =~ ^[1-9][0-9]*$ ]] || die "$value_name 必须是正整数，当前值：$value"
done
((START_CONCURRENCY <= END_CONCURRENCY)) || die "START_CONCURRENCY 不能大于 END_CONCURRENCY"

effective_capacity=$PREFILL_MAX_RUNNING_REQUESTS
((DECODE_MAX_RUNNING_REQUESTS < effective_capacity)) && effective_capacity=$DECODE_MAX_RUNNING_REQUESTS

if ((END_CONCURRENCY > effective_capacity)) && [[ $ALLOW_OVER_CAPACITY != 1 ]]; then
  die "扫描上限 $END_CONCURRENCY 超过服务端有效并发上限 $effective_capacity。请先修改 service/pd-config.sh 中的 PREFILL_MAX_RUNNING_REQUESTS/DECODE_MAX_RUNNING_REQUESTS 并重启，或明确设置 ALLOW_OVER_CAPACITY=1"
fi

if [[ $RESTART_SERVICE_EACH_RUN == 1 && $EUID -ne 0 ]]; then
  die "RESTART_SERVICE_EACH_RUN=1 时请使用 sudo -E 执行"
fi

run_dir="$RESULT_ROOT/sweep_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$run_dir"
status_file="$run_dir/status.tsv"
printf 'concurrency\tnum_prompts\texit_status\tresult_dir\n' >"$status_file"

echo "并发扫描：$START_CONCURRENCY..$END_CONCURRENCY，步长=$STEP"
echo "服务端有效并发上限：$effective_capacity"
echo "结果目录：$run_dir"

failed=0
for ((concurrency = START_CONCURRENCY; concurrency <= END_CONCURRENCY; concurrency += STEP)); do
  num_prompts=${NUM_PROMPTS_PER_CASE:-$concurrency}
  case_dir="$run_dir/c${concurrency}_p${num_prompts}"
  mkdir -p "$case_dir"

  if [[ $RESTART_SERVICE_EACH_RUN == 1 ]]; then
    echo "并发 $concurrency：重启当前 PD 服务（服务端并发配置不会被本脚本修改）"
    "$PD_ROOT_DIR/service/stop-pd.sh"
    "$PD_ROOT_DIR/service/start-pd.sh"
  fi

  echo "===== 并发 $concurrency，请求数 $num_prompts ====="
  set +e
  NUM_PROMPTS=$num_prompts \
    MAX_CONCURRENCY=$concurrency \
    RANDOM_INPUT_LEN=$RANDOM_INPUT_LEN \
    RANDOM_OUTPUT_LEN=$RANDOM_OUTPUT_LEN \
    WARMUP_REQUESTS=$WARMUP_REQUESTS \
    RESULT_DIR="$case_dir" \
    "$SCRIPT_DIR/run-benchmark.sh" 2>&1 | tee "$case_dir/benchmark.log"
  status=${PIPESTATUS[0]}
  set -e

  printf '%s\t%s\t%s\t%s\n' "$concurrency" "$num_prompts" "$status" "$case_dir" >>"$status_file"
  if ((status != 0)); then
    failed=1
    [[ $CONTINUE_ON_ERROR == 1 ]] || exit "$status"
  fi
done

echo "并发扫描完成：$run_dir"
exit "$failed"
