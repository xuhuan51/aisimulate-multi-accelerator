#!/usr/bin/env bash
# 用途：对六组固定序列长度工作负载分别进行并发扫描，保存每个并发点的日志、JSONL、配置和汇总结果。
#
# 默认扫描范围：
#   1. 3.5K/1.5K：8 16 32 64
#   2. 4K/1K：    8 16 32 64
#   3. 8K/1K：    4 8 16 32
#   4. 32K/1K：   1 2 4 8
#   5. 1K/32K：   1 2
#   6. 前缀缓存：  4 8 16 32

set -Eeuo pipefail

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
# shellcheck source=pd-common.sh
source "$SCRIPT_DIR/../../service/pd-common.sh"

BENCHMARK_SCRIPT="$SCRIPT_DIR/run-benchmark.sh"
SUMMARY_SCRIPT="$SCRIPT_DIR/summarize-workload-results.py"

CASES=${CASES:-"1 2 3 4 5 6"}
CASE1_CONCURRENCIES=${CASE1_CONCURRENCIES:-"8 16 32 64"}
CASE2_CONCURRENCIES=${CASE2_CONCURRENCIES:-"8 16 32 64"}
CASE3_CONCURRENCIES=${CASE3_CONCURRENCIES:-"4 8 16 32"}
CASE4_CONCURRENCIES=${CASE4_CONCURRENCIES:-"1 2 4 8"}
CASE5_CONCURRENCIES=${CASE5_CONCURRENCIES:-"1 2"}
CASE6_CONCURRENCIES=${CASE6_CONCURRENCIES:-"4 8 16 32"}

STANDARD_PROMPT_MULTIPLIER=${STANDARD_PROMPT_MULTIPLIER:-2}
LONG_PROMPT_MULTIPLIER=${LONG_PROMPT_MULTIPLIER:-1}
CASE1_WARMUP_REQUESTS=${CASE1_WARMUP_REQUESTS:-2}
CASE2_WARMUP_REQUESTS=${CASE2_WARMUP_REQUESTS:-2}
CASE3_WARMUP_REQUESTS=${CASE3_WARMUP_REQUESTS:-2}
CASE4_WARMUP_REQUESTS=${CASE4_WARMUP_REQUESTS:-2}
CASE5_WARMUP_REQUESTS=${CASE5_WARMUP_REQUESTS:-2}
CASE6_WARMUP_REQUESTS=${CASE6_WARMUP_REQUESTS:-2}

CACHE_CASE_MODE=${CACHE_CASE_MODE:-prefix32k}
CACHE_NUM_GROUPS=${CACHE_NUM_GROUPS:-4}
CACHE_PROMPTS_PER_GROUP=${CACHE_PROMPTS_PER_GROUP:-5}

REQUEST_RATE=${REQUEST_RATE:-inf}
RANDOM_RANGE_RATIO=${RANDOM_RANGE_RATIO:-1}
FLUSH_CACHE_BEFORE_POINT=${FLUSH_CACHE_BEFORE_POINT:-1}
STOP_CASE_ON_ERROR=${STOP_CASE_ON_ERROR:-1}
ALLOW_OVER_CAPACITY=${ALLOW_OVER_CAPACITY:-0}
RESUME=${RESUME:-1}
RESULT_ROOT=${RESULT_ROOT:-$PD_ROOT_DIR/results}
RUN_DIR=${RUN_DIR:-$RESULT_ROOT/workload-concurrency-sweep_$(date +%Y%m%d_%H%M%S)}

require_command python3
[[ -x $BENCHMARK_SCRIPT ]] || die "benchmark 脚本不存在或不可执行：$BENCHMARK_SCRIPT"
[[ -f $SUMMARY_SCRIPT ]] || die "汇总脚本不存在：$SUMMARY_SCRIPT"

is_positive_integer() {
  [[ $1 =~ ^[1-9][0-9]*$ ]]
}

for value_name in STANDARD_PROMPT_MULTIPLIER LONG_PROMPT_MULTIPLIER CACHE_NUM_GROUPS CACHE_PROMPTS_PER_GROUP; do
  value=${!value_name}
  is_positive_integer "$value" || die "$value_name 必须是正整数：$value"
done

for value_name in CASE1_WARMUP_REQUESTS CASE2_WARMUP_REQUESTS CASE3_WARMUP_REQUESTS CASE4_WARMUP_REQUESTS CASE5_WARMUP_REQUESTS CASE6_WARMUP_REQUESTS; do
  value=${!value_name}
  [[ $value =~ ^[0-9]+$ ]] || die "$value_name 必须是非负整数：$value"
done

for value_name in FLUSH_CACHE_BEFORE_POINT STOP_CASE_ON_ERROR ALLOW_OVER_CAPACITY RESUME; do
  value=${!value_name}
  [[ $value == 0 || $value == 1 ]] || die "$value_name 必须是 0 或 1：$value"
done

[[ $CACHE_CASE_MODE == prefix32k || $CACHE_CASE_MODE == total32k ]] || die "CACHE_CASE_MODE 只能是 prefix32k 或 total32k"

for case_id in $CASES; do
  [[ $case_id =~ ^[1-6]$ ]] || die "CASES 只能包含 1 到 6：$case_id"
done

case_selected() {
  local wanted=$1
  local item
  for item in $CASES; do
    [[ $item == "$wanted" ]] && return 0
  done
  return 1
}

effective_capacity=$PREFILL_MAX_RUNNING_REQUESTS
((DECODE_MAX_RUNNING_REQUESTS < effective_capacity)) && effective_capacity=$DECODE_MAX_RUNNING_REQUESTS

validate_concurrency_list() {
  local case_id=$1
  local list_name=$2
  local list_value=$3
  local concurrency
  [[ -n $list_value ]] || die "$list_name 不能为空"
  for concurrency in $list_value; do
    is_positive_integer "$concurrency" || die "$list_name 包含无效并发值：$concurrency"
    if ((concurrency > effective_capacity)) && [[ $ALLOW_OVER_CAPACITY != 1 ]]; then
      die "第 $case_id 组并发 $concurrency 超过服务端有效并发上限 $effective_capacity。修改服务配置并重启，或明确设置 ALLOW_OVER_CAPACITY=1"
    fi
  done
}

case_selected 1 && validate_concurrency_list 1 CASE1_CONCURRENCIES "$CASE1_CONCURRENCIES"
case_selected 2 && validate_concurrency_list 2 CASE2_CONCURRENCIES "$CASE2_CONCURRENCIES"
case_selected 3 && validate_concurrency_list 3 CASE3_CONCURRENCIES "$CASE3_CONCURRENCIES"
case_selected 4 && validate_concurrency_list 4 CASE4_CONCURRENCIES "$CASE4_CONCURRENCIES"
case_selected 5 && validate_concurrency_list 5 CASE5_CONCURRENCIES "$CASE5_CONCURRENCIES"
case_selected 6 && validate_concurrency_list 6 CASE6_CONCURRENCIES "$CASE6_CONCURRENCIES"

mkdir -p "$RUN_DIR"
status_file="$RUN_DIR/status.tsv"
if [[ ! -f $status_file || $RESUME == 0 ]]; then
  printf 'case\tname\tconcurrency\tnum_prompts\texit_status\telapsed_seconds\tresult_dir\n' >"$status_file"
fi

{
  echo "RUN_DIR=$RUN_DIR"
  echo "CASES=$CASES"
  echo "CASE1_CONCURRENCIES=$CASE1_CONCURRENCIES"
  echo "CASE2_CONCURRENCIES=$CASE2_CONCURRENCIES"
  echo "CASE3_CONCURRENCIES=$CASE3_CONCURRENCIES"
  echo "CASE4_CONCURRENCIES=$CASE4_CONCURRENCIES"
  echo "CASE5_CONCURRENCIES=$CASE5_CONCURRENCIES"
  echo "CASE6_CONCURRENCIES=$CASE6_CONCURRENCIES"
  echo "STANDARD_PROMPT_MULTIPLIER=$STANDARD_PROMPT_MULTIPLIER"
  echo "LONG_PROMPT_MULTIPLIER=$LONG_PROMPT_MULTIPLIER"
  echo "CACHE_CASE_MODE=$CACHE_CASE_MODE"
  echo "CACHE_NUM_GROUPS=$CACHE_NUM_GROUPS"
  echo "CACHE_PROMPTS_PER_GROUP=$CACHE_PROMPTS_PER_GROUP"
  echo "REQUEST_RATE=$REQUEST_RATE"
  echo "RANDOM_RANGE_RATIO=$RANDOM_RANGE_RATIO"
  echo "FLUSH_CACHE_BEFORE_POINT=$FLUSH_CACHE_BEFORE_POINT"
  echo "STOP_CASE_ON_ERROR=$STOP_CASE_ON_ERROR"
  echo "EFFECTIVE_SERVER_CAPACITY=$effective_capacity"
  echo "IMAGE=$IMAGE"
  echo "SERVED_MODEL_NAME=$SERVED_MODEL_NAME"
  echo "PREFILL_NODES=$PREFILL_NODES"
  echo "DECODE_NODES=$DECODE_NODES"
  echo "TP_SIZE=$TP_SIZE"
  echo "DP_SIZE=$DP_SIZE"
  echo "EP_SIZE=$EP_SIZE"
  echo "PREFILL_MAX_RUNNING_REQUESTS=$PREFILL_MAX_RUNNING_REQUESTS"
  echo "DECODE_MAX_RUNNING_REQUESTS=$DECODE_MAX_RUNNING_REQUESTS"
} >"$RUN_DIR/sweep-config.env"

run_point() {
  local case_id=$1
  local case_name=$2
  local dataset_name=$3
  local input_len=$4
  local output_len=$5
  local num_prompts=$6
  local concurrency=$7
  local warmup_requests=$8
  shift 8
  local ctag
  local point_name
  local point_dir
  local start_time
  local elapsed
  local status
  local -a extra_args=("$@")

  printf -v ctag '%04d' "$concurrency"
  point_name="${case_name}_c${concurrency}"
  point_dir="$RUN_DIR/${case_id}_${case_name}_c${ctag}"

  if [[ $RESUME == 1 && -f $point_dir/.complete ]]; then
    echo "跳过已完成并发点：第 $case_id 组，并发 $concurrency"
    return 0
  fi

  mkdir -p "$point_dir"
  {
    echo "CASE_ID=${case_id}-c${ctag}"
    echo "CASE_NAME=$point_name"
    echo "DATASET_NAME=$dataset_name"
    echo "INPUT_LENGTH=$input_len"
    echo "OUTPUT_LENGTH=$output_len"
    echo "NUM_PROMPTS=$num_prompts"
    echo "MAX_CONCURRENCY=$concurrency"
    echo "WARMUP_REQUESTS=$warmup_requests"
    echo "REQUEST_RATE=$REQUEST_RATE"
    echo "RANDOM_RANGE_RATIO=$RANDOM_RANGE_RATIO"
  } >"$point_dir/config.env"

  if [[ $FLUSH_CACHE_BEFORE_POINT == 1 ]]; then
    extra_args+=(--flush-cache)
  fi

  echo
  echo "===== 第 $case_id 组：$case_name，并发 $concurrency，请求数 $num_prompts ====="
  echo "结果目录：$point_dir"
  start_time=$(date +%s)

  set +e
  NUM_PROMPTS=$num_prompts \
    MAX_CONCURRENCY=$concurrency \
    RANDOM_INPUT_LEN=$input_len \
    RANDOM_OUTPUT_LEN=$output_len \
    RANDOM_RANGE_RATIO=$RANDOM_RANGE_RATIO \
    REQUEST_RATE=$REQUEST_RATE \
    WARMUP_REQUESTS=$warmup_requests \
    DATASET_NAME=$dataset_name \
    RESULT_DIR="$point_dir" \
    "$BENCHMARK_SCRIPT" "${extra_args[@]}" 2>&1 | tee "$point_dir/benchmark.log"
  status=${PIPESTATUS[0]}
  set -e

  elapsed=$(($(date +%s) - start_time))
  printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
    "$case_id" "$case_name" "$concurrency" "$num_prompts" "$status" "$elapsed" "$point_dir" >>"$status_file"

  if ((status == 0)); then
    touch "$point_dir/.complete"
  else
    rm -f "$point_dir/.complete"
  fi
  return "$status"
}

sweep_failed=0

run_random_sweep() {
  local case_id=$1
  local case_name=$2
  local input_len=$3
  local output_len=$4
  local multiplier=$5
  local warmup_requests=$6
  local concurrency_list=$7
  local concurrency
  local num_prompts

  case_selected "$case_id" || return 0
  for concurrency in $concurrency_list; do
    num_prompts=$((concurrency * multiplier))
    if ! run_point "$case_id" "$case_name" random-ids "$input_len" "$output_len" \
      "$num_prompts" "$concurrency" "$warmup_requests"; then
      sweep_failed=1
      if [[ $STOP_CASE_ON_ERROR == 1 ]]; then
        echo "第 $case_id 组在并发 $concurrency 失败，跳过该组更高并发，继续下一组。" >&2
        break
      fi
    fi
  done
}

run_cache_sweep() {
  local cache_prefix_len
  local cache_question_len
  local cache_name
  local cache_prompts
  local concurrency

  case_selected 6 || return 0
  if [[ $CACHE_CASE_MODE == prefix32k ]]; then
    cache_prefix_len=32768
    cache_question_len=21845
    cache_name=cache_prefix32k_output300_target60pct
  else
    cache_prefix_len=19661
    cache_question_len=13107
    cache_name=cache_total32k_output300_target60pct
  fi
  cache_prompts=$((CACHE_NUM_GROUPS * CACHE_PROMPTS_PER_GROUP))

  for concurrency in $CASE6_CONCURRENCIES; do
    if ! run_point 6 "$cache_name" generated-shared-prefix \
      "$((cache_prefix_len + cache_question_len))" 300 \
      "$cache_prompts" "$concurrency" "$CASE6_WARMUP_REQUESTS" \
      --gsp-num-groups "$CACHE_NUM_GROUPS" \
      --gsp-prompts-per-group "$CACHE_PROMPTS_PER_GROUP" \
      --gsp-system-prompt-len "$cache_prefix_len" \
      --gsp-question-len "$cache_question_len" \
      --gsp-output-len 300 \
      --gsp-range-ratio 1 \
      --cache-report; then
      sweep_failed=1
      if [[ $STOP_CASE_ON_ERROR == 1 ]]; then
        echo "第 6 组在并发 $concurrency 失败，跳过该组更高并发。" >&2
        break
      fi
    fi
  done
}

run_random_sweep 1 decode_3.5k_1.5k 3584 1536 \
  "$STANDARD_PROMPT_MULTIPLIER" "$CASE1_WARMUP_REQUESTS" "$CASE1_CONCURRENCIES"
run_random_sweep 2 fixed_4k_1k 4096 1024 \
  "$STANDARD_PROMPT_MULTIPLIER" "$CASE2_WARMUP_REQUESTS" "$CASE2_CONCURRENCIES"
run_random_sweep 3 long_context_8k_1k 8192 1024 \
  "$STANDARD_PROMPT_MULTIPLIER" "$CASE3_WARMUP_REQUESTS" "$CASE3_CONCURRENCIES"
run_random_sweep 4 long_text_32k_1k 32768 1024 \
  "$LONG_PROMPT_MULTIPLIER" "$CASE4_WARMUP_REQUESTS" "$CASE4_CONCURRENCIES"
run_random_sweep 5 long_output_1k_32k 1024 32768 \
  "$LONG_PROMPT_MULTIPLIER" "$CASE5_WARMUP_REQUESTS" "$CASE5_CONCURRENCIES"
run_cache_sweep

python3 "$SUMMARY_SCRIPT" "$RUN_DIR"
echo
echo "六组并发扫描执行结束：$RUN_DIR"
echo "状态汇总：$status_file"
echo "性能汇总：$RUN_DIR/summary.tsv"
exit "$sweep_failed"
