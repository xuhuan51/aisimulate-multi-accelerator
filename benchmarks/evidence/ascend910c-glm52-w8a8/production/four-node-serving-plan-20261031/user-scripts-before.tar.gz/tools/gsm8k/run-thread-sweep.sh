#!/usr/bin/env bash
# 用途：在不改动服务端配置的前提下，扫描 GSM8K 客户端并发线程数并分别保存准确率结果。

set -Eeuo pipefail

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
# shellcheck source=pd-common.sh
source "$SCRIPT_DIR/../../service/pd-common.sh"

THREADS=${THREADS:-"1 8 16 32"}
NUM_EXAMPLES=${NUM_EXAMPLES:-200}
ALLOW_OVER_CAPACITY=${ALLOW_OVER_CAPACITY:-0}
CONTINUE_ON_ERROR=${CONTINUE_ON_ERROR:-0}
RESULT_ROOT=${RESULT_ROOT:-$PD_ROOT_DIR/results/gsm8k/thread-sweep}
run_dir="$RESULT_ROOT/sweep_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$run_dir"

effective_capacity=$PREFILL_MAX_RUNNING_REQUESTS
((DECODE_MAX_RUNNING_REQUESTS < effective_capacity)) && effective_capacity=$DECODE_MAX_RUNNING_REQUESTS

for threads in $THREADS; do
  [[ $threads =~ ^[1-9][0-9]*$ ]] || die "THREADS 中包含非正整数：$threads"
  if ((threads > effective_capacity)) && [[ $ALLOW_OVER_CAPACITY != 1 ]]; then
    die "线程数 $threads 超过服务端有效并发上限 $effective_capacity；请先修改服务端限制并重启，或设置 ALLOW_OVER_CAPACITY=1"
  fi
done

printf 'threads\texit_status\trun_dir\n' >"$run_dir/status.tsv"
failed=0
for threads in $THREADS; do
  case_dir="$run_dir/threads_$threads"
  echo "===== GSM8K threads=$threads ====="
  set +e
  NUM_THREADS=$threads NUM_EXAMPLES=$NUM_EXAMPLES RUN_DIR="$case_dir" \
    "$SCRIPT_DIR/run-gsm8k.sh" "$@"
  status=$?
  set -e
  printf '%s\t%s\t%s\n' "$threads" "$status" "$case_dir" >>"$run_dir/status.tsv"
  if ((status != 0)); then
    failed=1
    [[ $CONTINUE_ON_ERROR == 1 ]] || exit "$status"
  fi
done

echo "GSM8K 线程扫描完成：$run_dir"
exit "$failed"
