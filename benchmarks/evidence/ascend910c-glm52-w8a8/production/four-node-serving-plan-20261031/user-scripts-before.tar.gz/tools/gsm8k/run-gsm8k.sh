#!/usr/bin/env bash
# 用途：使用当前 PD Router 运行 GSM8K 数学题准确率评测，并收集日志、JSON 和 HTML 结果。
#
# 默认评测 200 题；完整数据集有 1319 题，可设置 NUM_EXAMPLES=1319。

set -Eeuo pipefail

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
# shellcheck source=pd-common.sh
source "$SCRIPT_DIR/../../service/pd-common.sh"

require_command docker
require_controller_node
container_is_running "$ROUTER_IP" "$ROUTER_CONTAINER" || die "Router 容器未运行：$ROUTER_CONTAINER"
parse_prefill_node "${PREFILL_NODE_LIST[0]}" || die "无法解析 Prefill[0] 配置"
eval_container=$(prefill_container_name 0)
container_is_running "$NODE_IP" "$eval_container" || die "GSM8K 执行容器未运行：$eval_container"

NUM_EXAMPLES=${NUM_EXAMPLES:-200}
NUM_THREADS=${NUM_THREADS:-32}
NUM_SHOTS=${NUM_SHOTS:-5}
MAX_TOKENS=${MAX_TOKENS:-2048}
TEMPERATURE=${TEMPERATURE:-0.0}
TOP_P=${TOP_P:-1.0}
API=${API:-chat}
GSM8K_DATA_PATH=${GSM8K_DATA_PATH:-$SCRIPT_DIR/data/gsm8k_test.jsonl}
RESULT_ROOT=${RESULT_ROOT:-$PD_ROOT_DIR/results/gsm8k}
RUN_DIR=${RUN_DIR:-$RESULT_ROOT/gsm8k_$(date +%Y%m%d_%H%M%S)}

[[ -f $GSM8K_DATA_PATH ]] || die "GSM8K 数据文件不存在：$GSM8K_DATA_PATH"
mkdir -p "$RUN_DIR"
log_file="$RUN_DIR/eval.log"
container_data="/tmp/gsm8k_test_${$}.jsonl"

eval_command=(
  python3 -m sglang.test.run_eval
  --eval-name gsm8k
  --base-url "http://$ROUTER_IP:$ROUTER_PORT"
  --model "$SERVED_MODEL_NAME"
  --num-examples "$NUM_EXAMPLES"
  --num-threads "$NUM_THREADS"
  --num-shots "$NUM_SHOTS"
  --max-tokens "$MAX_TOKENS"
  --temperature "$TEMPERATURE"
  --top-p "$TOP_P"
  --api "$API"
  --gsm8k-data-path "$container_data"
  "$@"
)

cleanup() {
  docker exec "$eval_container" rm -f "$container_data" >/dev/null 2>&1 || true
}
trap cleanup EXIT

docker cp "$GSM8K_DATA_PATH" "$eval_container:$container_data" >/dev/null
printf '运行 GSM8K：'
printf '%q ' "${eval_command[@]}"
printf '\n结果目录：%s\n' "$RUN_DIR"

set +e
docker exec -e OPENAI_API_KEY="${OPENAI_API_KEY:-EMPTY}" "$eval_container" "${eval_command[@]}" 2>&1 | tee "$log_file"
eval_status=${PIPESTATUS[0]}
set -e

while IFS= read -r artifact; do
  [[ -n $artifact ]] || continue
  if docker exec "$eval_container" test -f "$artifact"; then
    docker cp "$eval_container:$artifact" "$RUN_DIR/$(basename "$artifact")" >/dev/null
    docker exec "$eval_container" rm -f "$artifact" >/dev/null
  fi
done < <(sed -n -e 's/^Writing report to //p' -e 's/^Writing results to //p' "$log_file")

echo "GSM8K 结果：$RUN_DIR"
exit "$eval_status"
