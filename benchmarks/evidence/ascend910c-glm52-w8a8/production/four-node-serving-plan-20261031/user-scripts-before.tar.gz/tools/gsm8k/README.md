# GSM8K 准确率评测

`run-gsm8k.sh` 在 `Prefill[0]` 容器中调用当前镜像自带的 `sglang.test.run_eval`，请求发送到 PD Router。这样不要求宿主机安装 SGLang/PyTorch，也不会在 Router 容器中加载 `torch_npu`。

快速检查：

```bash
NUM_EXAMPLES=20 NUM_THREADS=4 ./tools/gsm8k/run-gsm8k.sh
```

完整 1319 题：

```bash
NUM_EXAMPLES=1319 NUM_THREADS=32 ./tools/gsm8k/run-gsm8k.sh
```

扫描客户端线程数：

```bash
THREADS='1 8 16 32' NUM_EXAMPLES=200 ./tools/gsm8k/run-thread-sweep.sh
```

线程扫描只修改客户端并发，不会修改 `PREFILL_MAX_RUNNING_REQUESTS` 或 `DECODE_MAX_RUNNING_REQUESTS`。脚本默认拒绝超过服务端有效上限的配置。

`data/gsm8k_test.jsonl` 含 1319 条 GSM8K test 数据,数据取自 OpenAI `grade-school-math` 的 MIT 授权数据集。
