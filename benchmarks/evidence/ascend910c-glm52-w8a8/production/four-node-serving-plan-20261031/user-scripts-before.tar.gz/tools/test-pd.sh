#!/usr/bin/env bash
# 用途：通过统一 Router 向 GLM-5.2 多 P/多 D 服务发送一个最小生成请求，验证完整调用链路。

set -Eeuo pipefail

# shellcheck source=pd-common.sh
source "$(dirname "$0")/../service/pd-common.sh"

require_command curl
require_command python3

PROMPT=${PROMPT:-Say hello in one short sentence.}
MAX_NEW_TOKENS=${MAX_NEW_TOKENS:-32}

curl -fsS "http://$ROUTER_IP:$ROUTER_PORT/generate" \
  -H 'Content-Type: application/json' \
  --data "$(printf '{\"text\":%s,\"sampling_params\":{\"max_new_tokens\":%s,\"temperature\":0}}' \
    "$(python3 -c 'import json,sys; print(json.dumps(sys.argv[1]))' "$PROMPT")" \
    "$MAX_NEW_TOKENS")"
printf '\n'
