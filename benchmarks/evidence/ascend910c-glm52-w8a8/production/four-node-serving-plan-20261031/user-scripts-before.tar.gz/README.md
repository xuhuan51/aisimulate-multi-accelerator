# GLM-5.2 Ascend 多 P/多 D 启动脚本

本目录用于在多台 Ascend 服务器上部署多个 Prefill、多个 Decode，并由第一台 Prefill 提供统一 Router 和共享 MemFabric Store。默认配置仍是 1P1D，可直接扩展为 2P1D、2P2D 或其他节点数量。

## 目录结构

- `service/`：拓扑配置、启动、停止、状态、日志及 Worker 内部脚本。
- `check/`：离线配置检查、在线环境检查和端口检查。
- `tools/`：请求测试、GSM8K、性能测试/采样和不同输入长度正确性复现。

## 拓扑配置

所有配置集中在 `service/pd-config.sh`。

Prefill 节点格式：

```text
IP:HTTP端口:Bootstrap端口
```

Decode 节点格式：

```text
IP:HTTP端口
```

默认 1P1D：

```bash
PREFILL_NODES="10.120.72.31:8000:8998"
DECODE_NODES="10.120.72.32:8003"
```

扩展为 2P2D：

```bash
PREFILL_NODES="10.120.72.31:8000:8998 10.120.72.33:8000:8998"
DECODE_NODES="10.120.72.32:8003 10.120.72.34:8003"
```

当前拓扑规则：

1. 第一台 Prefill 同时是控制节点、Router 节点和 MemFabric Store 节点。
2. `start-pd.sh`、`stop-pd.sh` 等管理命令都在第一台 Prefill 上执行。
3. 每个 Worker 默认独占一台机器的 16 个 NPU，因此同一 IP 不能重复配置为多个 Worker。
4. 所有 Prefill 和 Decode 使用相同镜像、模型路径、通信网卡和并行参数。
5. 每台远端 Worker 会自动收到运行所需脚本，不需要手工复制。

## 检查配置

修改 `service/pd-config.sh` 后，先运行离线检查：

```bash
./check/check-config.sh
```

该检查不连接远端机器，会检查：

- Prefill/Decode 格式和 IP 地址。
- 节点是否重复。
- HTTP、Bootstrap、Router、Store 端口是否冲突。
- Router 和 Store 是否位于第一台 Prefill。
- TP/DP 整除关系及 Decode Graph batch 是否有效。
- 远端目录是否包含空格。

也可以不修改文件，临时检查一个 2P2D 配置：

```bash
PREFILL_NODES="10.120.72.31:8000:8998 10.120.72.33:8000:8998" \
DECODE_NODES="10.120.72.32:8003 10.120.72.34:8003" \
./check/check-config.sh
```

离线配置通过后，再进行在线环境检查：

```bash
sudo -E ./check/check-pd-env.sh
```

在线检查会逐台验证 SSH root 登录、模型、镜像、通信网卡、Ascend 驱动和 NPU 数量。

## 启动服务

```bash
sudo -E ./service/start-pd.sh
```

启动顺序如下：

1. 检查拓扑和所有节点环境。
2. 向所有远端 Worker 同步脚本。
3. 清理旧的同名容器并预检查所有端口。
4. 启动第一台 Prefill，等待共享 MemFabric Store。
5. 启动其余 Prefill 和所有 Decode。
6. 等待每个 Worker 健康检查通过。
7. 将所有 Prefill/Decode 注册到 Router。

Router 会为每个 Worker 分别追加参数：

```text
--prefill http://P_IP:P_PORT P_BOOTSTRAP
--decode http://D_IP:D_PORT
```

## 日常管理

查看所有 Worker 和 Router：

```bash
./service/status-pd.sh
```

列出日志索引：

```bash
./service/logs-pd.sh list
```

查看指定 Worker 日志：

```bash
./service/logs-pd.sh prefill 0
./service/logs-pd.sh prefill 1 --tail 200
./service/logs-pd.sh decode 0
./service/logs-pd.sh router
```

测试 Router：

```bash
./tools/test-pd.sh
```

运行随机 serving benchmark：

```bash
NUM_PROMPTS=100 \
MAX_CONCURRENCY=16 \
RANDOM_INPUT_LEN=4096 \
RANDOM_OUTPUT_LEN=256 \
./tools/performance/run-benchmark.sh
```
默认在 `Prefill[0]` 容器内执行 benchmark 客户端，请求仍发送到 Router。数据集默认为 `random-ids`，不需要访问 Hugging Face 或准备 ShareGPT 文件。

更多工具：

```bash
# GSM8K 数学题准确率
NUM_EXAMPLES=200 NUM_THREADS=32 ./tools/gsm8k/run-gsm8k.sh

# 客户端并发扫描（会检查服务端 MAX_RUNNING_REQUESTS）
START_CONCURRENCY=1 END_CONCURRENCY=32 ./tools/performance/run-concurrency-sweep.sh

# 20/50/80 条账本输入的 token 统计与自动判分
./tools/correctness/run-all.sh
```

各目录的参数和限制见 `tools/gsm8k/README.md`、`tools/performance/README.md` 和 `tools/correctness/README.md`。


停止全部 Worker 和 Router：

```bash
sudo -E ./service/stop-pd.sh
```

## 主要文件

| 文件 | 用途 |
|---|---|
| `service/pd-config.sh` | 多 P/多 D 拓扑及公共推理参数 |
| `service/start-pd.sh` | 同步并启动全部 Worker 和 Router |
| `service/stop-pd.sh` | 停止全部 Worker 和 Router |
| `service/status-pd.sh` | 查看全部节点状态 |
| `service/logs-pd.sh` | 按角色和索引查看日志 |
| `check/check-config.sh` | 离线检查拓扑和参数 |
| `check/check-pd-env.sh` | 在线检查所有节点环境 |
| `check/check-ports.py` | 启动前检查端口绑定 |
| `tools/test-pd.sh` | 通过 Router 测试请求 |
| `tools/performance/` | serving benchmark、并发扫描、Worker profile  |
| `tools/gsm8k/` | GSM8K 准确率评测及 1319 题本地数据 |

## 注意事项

- 新增 Worker 后，两端必须都有完整模型和相同 Docker 镜像。
- 当前每个 Worker 使用 `TP_SIZE=16` 和全部 16 个 NPU，不支持在同一台机器上直接放两个 Worker。
- Decode Graph 默认 batch 为 `8 16 24 32`。修改 TP/DP 后必须先运行 `check-config.sh`。
- `start-pd.sh` 会删除配置中对应的同名容器，但不会删除镜像、模型或 benchmark 结果。
- 设置 `ENABLE_SYSTEM_TUNING=0` 可以跳过 CPU governor 和 sysctl 调优。
