"""Measure DeepEP timing as Graph depth changes, using installed SGLang APIs.

The invocation boundary follows SGLang token_dispatcher/deepep.py at
76f9213a411018547f4fd6a75f36feaa4d6bed58 and
baa9befa381511cd4d56f83980951e5a45fffc6d, Apache-2.0, SGLang contributors.
This independent diagnostic calls those implementations without copying kernels.
"""

import argparse
from datetime import timedelta
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import statistics
import subprocess
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--model-metadata', required=True)
    parser.add_argument('--expected-revision', required=True)
    parser.add_argument('--capacity', type=int, required=True)
    parser.add_argument('--tokens', type=int, default=2)
    parser.add_argument('--attention-dp', type=int, default=4)
    parser.add_argument('--depths', default='1,8,75')
    parser.add_argument('--iterations', type=int, default=20)
    parser.add_argument('--repeats', type=int, default=7)
    parser.add_argument('--warmup', type=int, default=5)
    parser.add_argument('--profile', action='store_true')
    parser.add_argument('--negative-control', action='store_true')
    args = parser.parse_args()
    assert args.capacity in [8, 16, 32] and 0 < args.tokens <= args.capacity
    assert args.repeats >= 3 and args.iterations >= 10
    assert os.environ['SGLANG_DEEPEP_NUM_MAX_DISPATCH_TOKENS_PER_RANK'] == str(args.capacity)

    import torch
    import torch.distributed as dist
    import torch_npu

    from sglang.srt.distributed.parallel_state import get_torch_distributed_pg_options
    from sglang.srt.hardware_backend.npu.utils import init_npu_backend
    from sglang.srt.layers.moe.token_dispatcher.deepep import _DeepEPDispatcherImplLowLatency
    from sglang.srt.layers.moe.topk import StandardTopKOutput
    from sglang.srt.layers.moe.utils import DeepEPMode
    from sglang.srt.runtime_context import publish
    from sglang.srt.server_args import ServerArgs

    revision = subprocess.check_output(['git', '-C', '/sgl-workspace/sglang', 'rev-parse', 'HEAD'], text=True).strip()
    assert revision == args.expected_revision
    rank, world, local_rank = [int(os.environ[key]) for key in ['RANK', 'WORLD_SIZE', 'LOCAL_RANK']]
    assert world == 16
    allowed = sorted(os.sched_getaffinity(0))
    affinity = [allowed[(2 * local_rank + offset) % len(allowed)] for offset in [0, 1]]
    os.sched_setaffinity(0, affinity)
    init_npu_backend()
    torch.npu.set_device(local_rank)
    torch.set_num_threads(1)
    torch.set_grad_enabled(False)
    dist.init_process_group('hccl', timeout=timedelta(seconds=300), pg_options=get_torch_distributed_pg_options())
    control = dist.new_group(backend='gloo', timeout=timedelta(seconds=300))

    publish(ServerArgs(
        model_path=args.model_metadata, device='npu', tp_size=16, ep_size=16,
        dp_size=args.attention_dp, enable_dp_attention=True, enable_dp_lm_head=True,
        moe_a2a_backend='deepep', quantization='modelslim', dtype='bfloat16',
        context_length=180000, disable_shared_experts_fusion=True,
    ), role='scheduler')
    dispatcher = _DeepEPDispatcherImplLowLatency(
        return_recv_hook=True, group=dist.group.WORLD, router_topk=8,
        permute_fusion=False, num_experts=256, num_local_experts=16,
        hidden_size=6144, params_dtype=torch.bfloat16, deepep_mode=DeepEPMode.AUTO,
    )
    dispatcher.set_quant_config({'dispatcher_output_dtype': 'int8'})
    assert dispatcher.num_max_dispatch_tokens_per_rank == args.capacity
    args.output.mkdir(parents=True, exist_ok=True)

    def barrier():
        dist.barrier(group=control)

    token_ids = torch.arange(args.tokens, device='npu', dtype=torch.int64) + rank * args.tokens
    columns = torch.arange(6144, device='npu', dtype=torch.int64)
    inputs = ((token_ids[:, None] * 13 + columns[None, :]) % 15 - 7).to(torch.bfloat16)
    inputs[:, 0] = (token_ids % 127).to(torch.bfloat16)
    inputs[:, 1] = (token_ids // 127 % 127).to(torch.bfloat16)
    inputs[:, 2] = 0
    inputs[:, -1] = 127
    ids = (token_ids[:, None] * 17 + torch.arange(8, device='npu', dtype=torch.int64) * 31) % 256
    weights = torch.full((args.tokens, 8), 0.125, device='npu', dtype=torch.float32)
    topk = StandardTopKOutput(weights, ids.to(torch.int32), torch.empty(args.tokens, 256, device='npu', dtype=torch.bfloat16))
    all_ids = torch.arange(world * args.tokens, dtype=torch.int64)
    all_experts = (all_ids[:, None] * 17 + torch.arange(8)[None, :] * 31) % 256
    expected = [all_ids[(all_experts == rank * 16 + expert).any(-1)] for expert in range(16)]
    expected_counts = [len(ids) for ids in expected]
    saved = {}

    def dispatch():
        result = dispatcher.dispatch_b(*dispatcher.dispatch_a(inputs, topk))
        saved['handle'] = dispatcher.handle
        saved['counts'] = dispatcher.packed_recv_count
        return result

    first = dispatch()
    torch.npu.synchronize()
    assert first.hidden_states.dtype == torch.int8 and first.hidden_states_scale.dtype == torch.float32
    combine_values = (first.hidden_states.float() * first.hidden_states_scale.reshape(-1, 1)).to(torch.bfloat16)

    def combine():
        dispatcher.handle = saved['handle']
        dispatcher.packed_recv_count = saved['counts']
        return dispatcher.combine_b(*dispatcher.combine_a(combine_values, ids, weights))

    def pair():
        dispatched = dispatch()
        return dispatched, combine()

    def check_dispatch(result, sign):
        raw = result.masked_m
        counts = raw.cpu().tolist() if isinstance(raw, torch.Tensor) else list(raw)
        assert counts == expected_counts, (counts, expected_counts)
        valid = sum(counts)
        values = result.hidden_states[:valid].cpu() * sign
        scales = result.hidden_states_scale[:valid].cpu()
        assert torch.equal(scales, torch.ones_like(scales))
        offset = 0
        for count, expected_ids in zip(counts, expected):
            if count:
                part = values[offset:offset + count]
                observed = part[:, 0].long() + part[:, 1].long() * 127 + part[:, 2].long() * 127 * 127
                order = observed.argsort()
                assert torch.equal(observed[order], expected_ids)
                wanted = ((expected_ids[:, None] * 13 + torch.arange(6144)[None, :]) % 15 - 7).to(torch.int8)
                wanted[:, 0] = (expected_ids % 127).to(torch.int8)
                wanted[:, 1] = (expected_ids // 127 % 127).to(torch.int8)
                wanted[:, 2] = 0
                wanted[:, -1] = 127
                assert torch.equal(part[order], wanted)
            offset += count
        return valid * 6144

    check_dispatch(first, 1)
    barrier()
    assert torch.equal(combine(), inputs)
    torch.npu.synchronize()
    barrier()
    local_meta = {
        'rank': rank, 'local_rank': local_rank, 'cpu_affinity': sorted(os.sched_getaffinity(0)),
        'device': torch.npu.get_device_name(local_rank), 'received_shape': list(first.hidden_states.shape),
        'expected_counts': expected_counts,
    }
    ranks = [None] * world
    dist.all_gather_object(ranks, local_meta, group=control)
    record = {
        'schema': 'ep-paired-graph-diagnostic/v1', 'status': 'running', 'negative_control': args.negative_control,
        'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'runtime': {'framework_commit': revision, 'torch': torch.__version__, 'torch_npu': torch_npu.__version__,
                    'deep_ep': importlib.metadata.version('deep_ep')},
        'capacity': args.capacity, 'tokens_per_rank': args.tokens, 'attention_dp': args.attention_dp,
        'ranks': ranks, 'protocol': {'iterations': args.iterations, 'repeats': args.repeats, 'warmup': args.warmup,
                                    'profile_warmup': args.warmup, 'measurement': 'outer NPU events, one replay per sample, control barrier outside timed interval'},
        'scope': 'isolated dispatch/combine and their pair; fixed synthetic balanced routing; no expert compute or model forward',
        'cases': [],
    }

    def save():
        if rank == 0:
            temporary = args.output / 'results.tmp'
            temporary.write_text(json.dumps(record, indent=2))
            temporary.replace(args.output / 'results.json')

    save()
    sign = 1
    retained_graphs = []
    for operation, invoke in [('pair', pair)]:
        for depth in map(int, args.depths.split(',')):
            if rank == 0:
                print(json.dumps({'stage': 'capture', 'operation': operation, 'depth': depth}), flush=True)
            barrier()
            for _ in range(args.warmup):
                invoke()
            torch.npu.synchronize()
            graph = torch.npu.NPUGraph()
            with torch.npu.graph(graph):
                outputs = [invoke() for _ in range(depth)]
            retained_graphs.append((graph, outputs))
            barrier()
            for _ in range(args.warmup):
                graph.replay()
                torch.npu.synchronize()
                barrier()

            def verify():
                nonlocal sign
                sign = -sign
                inputs.neg_()
                combine_values.neg_()
                torch.npu.synchronize()
                barrier()
                if not args.negative_control:
                    graph.replay()
                torch.npu.synchronize()
                checked = 0
                for dispatched, combined in outputs:
                    checked += check_dispatch(dispatched, sign)
                    assert torch.equal(combined, inputs)
                    checked += combined.numel()
                return checked

            before = verify()
            samples, wall_samples = [], []
            for _ in range(args.repeats):
                elapsed, wall = [], []
                for _ in range(args.iterations):
                    barrier()
                    begin, end = torch.npu.Event(enable_timing=True), torch.npu.Event(enable_timing=True)
                    started = time.perf_counter()
                    begin.record()
                    graph.replay()
                    end.record()
                    end.synchronize()
                    elapsed.append(begin.elapsed_time(end))
                    wall.append((time.perf_counter() - started) * 1000)
                samples.append(statistics.mean(elapsed))
                wall_samples.append(statistics.mean(wall))
            after = verify()
            gathered = [None] * world
            dist.all_gather_object(gathered, {'rank': rank, 'samples_ms': samples, 'wall_samples_ms': wall_samples,
                                            'checked_elements': before + after}, group=control)
            critical = [max(row['samples_ms'][index] for row in gathered) for index in range(args.repeats)]
            mean = statistics.mean(critical)
            result = {'operation': operation, 'depth': depth, 'rank_results': gathered,
                      'critical_samples_ms': critical, 'median_graph_ms': statistics.median(critical),
                      'median_per_call_ms': statistics.median(critical) / depth,
                      'cv': statistics.pstdev(critical) / mean, 'execution_verification': 'captured_graph_replay',
                      'validation': 'passed'}
            record['cases'].append(result)
            save()
            if rank == 0:
                print(json.dumps({key: value for key, value in result.items() if key != 'rank_results'}), flush=True)
            if args.profile and operation == 'pair' and depth == 75:
                from torch_npu.profiler import ProfilerActivity, profile, tensorboard_trace_handler
                profile_samples = []
                with profile(activities=[ProfilerActivity.CPU, ProfilerActivity.NPU], record_shapes=False, with_stack=False,
                             experimental_config=torch_npu.profiler._ExperimentalConfig(profiler_level=torch_npu.profiler.ProfilerLevel.Level0),
                             on_trace_ready=tensorboard_trace_handler(str(args.output / 'profile'))) as profiler:
                    for _ in range(args.warmup):
                        barrier()
                        graph.replay()
                        torch.npu.synchronize()
                        profiler.step()
                    for sample in range(args.repeats):
                        barrier()
                        begin, end = torch.npu.Event(enable_timing=True), torch.npu.Event(enable_timing=True)
                        begin.record()
                        graph.replay()
                        end.record()
                        end.synchronize()
                        profile_samples.append(begin.elapsed_time(end))
                        profiler.step()
                    barrier()
                profile_ranks = [None] * world
                dist.all_gather_object(profile_ranks, {'rank': rank, 'graph_event_ms': profile_samples}, group=control)
                result['profiled_graph_events'] = profile_ranks
                save()
                barrier()
    record['status'] = 'completed'
    save()
    barrier()
    dist.destroy_process_group()


if __name__ == '__main__':
    main()
