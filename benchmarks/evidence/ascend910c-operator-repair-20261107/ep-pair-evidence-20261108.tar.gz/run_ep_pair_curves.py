import pathlib,json,subprocess,time,shutil
root=pathlib.Path('/home/wuliang/aisimulate-repair-20261108')
source=root/'probe_ep_pair_steady.py';assert not source.exists();shutil.copyfile(root/'probe_ep_pair.py',source)
original=json.loads((root/'ep-pair-m1-r0/launch.json').read_text())['command']
results=[]
def save(status,current=None,error=None):
 (root/'ep-pair-campaign-status.json').write_text(json.dumps(dict(status=status,current=current,error=error,runs=results,unix=time.time()),indent=2))
try:
 for tokens,negative in [(1,False),(2,False),(3,False),(4,False),(8,False),(16,False),(32,False),(1,True)]:
  label='ep-pair-m'+str(tokens)+('-negative-r0' if negative else '-steady-r0');run=root/label;run.mkdir(exist_ok=False)
  cmd=original[:];cmd[cmd.index('--name')+1]='wuliang-'+label+'-20261108';cmd[cmd.index('--output')+1]='/experiment/'+label;cmd[cmd.index('--tokens')+1]=str(tokens);cmd[cmd.index('/experiment/probe_ep_pair.py')]='/experiment/probe_ep_pair_steady.py'
  if negative:cmd+=['--negative-control']
  (run/'launch.json').write_text(json.dumps(dict(command=cmd),indent=2));save('running',label)
  with (run/'runner.log').open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=1590)
  result=dict(run=label,tokens=tokens,negative_control=negative,exit_code=p.returncode);results.append(result)
  if negative:
   assert p.returncode!=0 and 'numerical' in (run/'runner.log').read_text().lower(),result
  else:
   assert p.returncode==0,result
   d=json.loads((run/'results.json').read_text());assert d['status']=='completed' and len(d['cases'])==1
 save('completed')
except BaseException as error:
 save('failed',error=repr(error));raise
