"""Qualify actual paired-Graph stage intervals without changing table columns."""

import collections
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import statistics


ROOT = Path('/home/wuliang/aisimulate-repair-20261108')
TOKENS = (1, 2, 3, 4, 8, 16, 32)
IMAGE = 'sha256:d4c350d7d4e233d3cd203d2f783467c5f5be1453b9eee073f71b758069392edb'
DISPATCH = 'MoeLowLatencyDispatchV2'
COMBINE = 'MoeLowLatencyCombineV2'
CAST = 'aclnnInplaceCopy_CastAiCore_Cast'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    review = json.loads((ROOT / 'ep-pair-campaign-review.json').read_text())
    assert review['status'] == 'completed_with_expected_negative_rejection' and review['positive_cases'] == 7
    source = ROOT / 'probe_ep_pair_steady.py'
    source_hash = digest(source)
    rows, points, sources = [], [], []
    runtime = protocol = affinities = None
    for tokens in TOKENS:
        run = ROOT / f'ep-pair-m{tokens}-steady-r0'
        record = json.loads((run / 'results.json').read_text())
        command = json.loads((run / 'launch.json').read_text())['command']
        assert IMAGE in command and '/experiment/probe_ep_pair_steady.py' in command
        assert record['status'] == 'completed' and not record['negative_control']
        assert record['source_sha256'] == source_hash and record['capacity'] == 32 and record['tokens_per_rank'] == tokens
        assert record['runtime']['framework_commit'] == 'baa9befa381511cd4d56f83980951e5a45fffc6d'
        assert record['runtime']['torch_npu'] == '2.10.0.post6'
        assert record['protocol']['profile_warmup'] == record['protocol']['warmup'] == 3
        assert record['protocol']['repeats'] == 7
        current_affinities = [rank['cpu_affinity'] for rank in record['ranks']]
        if runtime is None:
            runtime, protocol, affinities = record['runtime'], record['protocol'], current_affinities
        assert (runtime, protocol, affinities) == (record['runtime'], record['protocol'], current_affinities)
        case, = record['cases']
        assert case['operation'] == 'pair' and case['depth'] == 75 and case['validation'] == 'passed'
        assert [rank['rank'] for rank in case['rank_results']] == list(range(16))
        assert sum(sum(rank['expected_counts']) for rank in record['ranks']) == 16 * tokens * 8
        for rank in case['rank_results']:
            expected = 2 * 75 * (sum(record['ranks'][rank['rank']]['expected_counts']) + tokens) * 6144
            assert rank['checked_elements'] == expected, (tokens, rank['rank'])
        rank_samples = {}
        files = list((run / 'profile').glob('*_ascend_pt/ASCEND_PROFILER_OUTPUT/kernel_details.csv'))
        assert len(files) == 16
        spans, stage_sums, closures = [], [], []
        for path in files:
            raw = list(csv.DictReader(path.open()))
            devices = {int(row['Device_id']) for row in raw}
            rank, = devices
            assert rank not in rank_samples
            assert len(raw) == (3 + 7) * 75 * 5, (tokens, rank, len(raw))
            raw.sort(key=lambda row: Decimal(row['Start Time(us)'].strip()))
            pairs = []
            for index in range(0, len(raw), 5):
                group = raw[index:index+5]
                assert [row['Name'] for row in group] == [CAST, CAST, DISPATCH, CAST, COMBINE]
                start = Decimal(group[0]['Start Time(us)'].strip())
                boundary = Decimal(group[2]['Start Time(us)'].strip()) + Decimal(group[2]['Duration(us)'])
                end = Decimal(group[4]['Start Time(us)'].strip()) + Decimal(group[4]['Duration(us)'])
                assert start < boundary < end
                pairs.append((start, boundary, end))
            samples = dict(dispatch=[], combine=[])
            event_samples = case['profiled_graph_events'][rank]
            assert event_samples['rank'] == rank and len(event_samples['graph_event_ms']) == 7
            for sample in range(7):
                selected = pairs[(3+sample)*75:(4+sample)*75]
                dispatch_ms = sum(float(boundary-start) for start,boundary,end in selected)/1000
                combine_ms = sum(float(end-boundary) for start,boundary,end in selected)/1000
                span_ms = float(selected[-1][2]-selected[0][0])/1000
                event_ms = event_samples['graph_event_ms'][sample]
                closure = (dispatch_ms+combine_ms)/event_ms
                assert 0.90 <= (dispatch_ms+combine_ms)/span_ms <= 1.01, (tokens, rank, sample, span_ms)
                assert span_ms <= event_ms*1.01, (tokens, rank, sample, span_ms,event_ms)
                samples['dispatch'].append(dispatch_ms/75)
                samples['combine'].append(combine_ms/75)
                spans.append(span_ms)
                stage_sums.append(dispatch_ms+combine_ms)
                closures.append(closure)
            rank_samples[rank] = samples
            sources.append(dict(tokens=tokens, rank=rank, kernel_csv=str(path), kernel_csv_sha256=digest(path)))
        point = dict(tokens=tokens, original_pair_event_median_ms=case['median_graph_ms'],
                     original_pair_event_cv=case['cv'],
                     profiled_interval_to_event_range=[min(closures),max(closures)], operations={})
        assert set(rank_samples) == set(range(16))
        for operation in ('dispatch', 'combine'):
            critical = [max(rank_samples[rank][operation][sample] for rank in range(16)) for sample in range(7)]
            latency = statistics.median(critical)
            variation = statistics.pstdev(critical)/statistics.mean(critical)
            checks = sum(2*75*(sum(rank['expected_counts']) if operation == 'dispatch' else tokens)*6144
                         for rank in record['ranks'])
            rows.append(dict(phase='low_latency', num_ranks=16, ranks_per_node=16,
                             rank_layout='contiguous', tokens_per_rank=tokens, distribution='balanced',
                             execution_mode='graph', hidden_size=6144, num_experts=256, topk=8,
                             max_dispatch_tokens_per_rank=32, operation=operation,
                             dispatch_dtype='int8', combine_dtype='bfloat16',
                             kernel_source='sglang.srt.layers.moe.token_dispatcher.deepep._DeepEPDispatcherImplLowLatency',
                             execution_verification='captured_graph_replay', latency_ms=latency, cv=variation,
                             sample_count=7, numerical_checks=checks, source_sha256=digest(run/'results.json')))
            point['operations'][operation] = dict(latency_ms=latency, cv=variation, critical_samples_ms=critical)
        points.append(point)
    identity = dict(runtime=runtime, image=IMAGE, collector_source_sha256=source_hash,
                    protocol=protocol, cpu_affinities=affinities, depth=75,
                    measurement='Per-stage device intervals in a paired Graph. Dispatch includes its two casts. Combine starts at Dispatch end and includes the final cast. Three profiled warmup Graphs are excluded by the frozen protocol.',
                    scope='Synthetic balanced routing and synchronous independent rank arrival. Model expert arrival waits are outside this calibration.')
    identity_hash = hashlib.sha256(json.dumps(identity,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    for row in rows:
        row['runtime_identity_sha256'] = identity_hash
    rejected = [dict(tokens=row['tokens_per_rank'],operation=row['operation'],cv=row['cv'])
                for row in rows if row['cv'] > 0.1]
    report = dict(status='qualified' if not rejected else 'needs_recollection', identity=identity,
                  identity_sha256=identity_hash, points=points, sources=sources, rejected=rejected)
    (ROOT/'ep-pair-qualified-rows.json').write_text(json.dumps(rows,indent=2))
    (ROOT/'ep-pair-qualification.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(dict(status=report['status'], points=points, rejected=rejected)))


if __name__ == '__main__':
    main()
